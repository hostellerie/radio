<?php
if (!isset($GLOBALS['_CONF'])) {
    die('This file cannot be used on its own.');
}

function RADIO_adminTemplate($file)
{
    global $_CONF;
    $template = COM_newTemplate($_CONF['path'] . 'plugins/radio/templates/admin');
    $template->set_file('page', $file);
    return $template;
}

function RADIO_adminHeaderCode()
{
    return '<meta name="robots" content="noindex,nofollow">' . "\n";
}

function RADIO_adminConfigurationButton()
{
    global $_CONF, $LANG_RADIO;

    if (!SEC_hasRights('config.radio.tab_main')) {
        return '';
    }

    $template = RADIO_adminTemplate('configuration-button.thtml');
    $template->set_var(array(
        'configuration_url' => htmlspecialchars(
            $_CONF['site_admin_url'] . '/configuration.php',
            ENT_QUOTES,
            'UTF-8'
        ),
        'configuration_label' => htmlspecialchars(
            $LANG_RADIO['admin_configuration'],
            ENT_QUOTES,
            'UTF-8'
        )
    ));

    return $template->finish($template->parse('output', 'page'));
}

function RADIO_adminNavItem($active, $key, $url, $label, $allowed)
{
    if (!$allowed) {
        return '';
    }

    return '<a class="' . ($active === $key ? 'is-active' : '') . '" href="'
        . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '">'
        . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</a>';
}

function RADIO_adminNavigation($active)
{
    global $_CONF, $LANG_RADIO;

    $adminBase = $_CONF['site_admin_url'] . '/plugins/radio/';
    $template = RADIO_adminTemplate('navigation.thtml');
    $template->set_var(array(
        'nav_aria_label' => htmlspecialchars($LANG_RADIO['admin_navigation'], ENT_QUOTES, 'UTF-8'),
        'nav_library' => RADIO_adminNavItem(
            $active,
            'library',
            $adminBase . 'index.php',
            $LANG_RADIO['library'],
            SEC_hasRights('radio.admin')
        ),
        'nav_programs' => RADIO_adminNavItem(
            $active,
            'programs',
            $adminBase . 'programs.php',
            $LANG_RADIO['programs'],
            SEC_hasRights('radio.schedule')
        ),
        'nav_schedule' => RADIO_adminNavItem(
            $active,
            'schedule',
            $adminBase . 'schedule.php',
            $LANG_RADIO['schedule'],
            SEC_hasRights('radio.schedule')
        ),
        'nav_rotation' => RADIO_adminNavItem(
            $active,
            'rotation',
            $adminBase . 'rotation.php',
            $LANG_RADIO['automatic_rotation'],
            SEC_hasRights('radio.admin')
        ),
        'nav_sources' => RADIO_adminNavItem(
            $active,
            'sources',
            $adminBase . 'sources.php',
            $LANG_RADIO['feed_sources'],
            SEC_hasRights('radio.admin')
        ),
        'nav_stats' => RADIO_adminNavItem(
            $active,
            'stats',
            $adminBase . 'stats.php',
            $LANG_RADIO['statistics'],
            SEC_hasRights('radio.admin')
        )
    ));

    return $template->finish($template->parse('output', 'page'));
}

function RADIO_adminRenderPage($active, $title, $intro, $helpTitle, $helpText, $pageContent, $message)
{
    $template = RADIO_adminTemplate('page.thtml');
    $template->set_var(array(
        'page_title' => htmlspecialchars($title, ENT_QUOTES, 'UTF-8'),
        'page_intro' => htmlspecialchars($intro, ENT_QUOTES, 'UTF-8'),
        'configuration_button' => RADIO_adminConfigurationButton(),
        'navigation' => RADIO_adminNavigation($active),
        'message' => $message,
        'help_title' => htmlspecialchars($helpTitle, ENT_QUOTES, 'UTF-8'),
        'help_text' => htmlspecialchars($helpText, ENT_QUOTES, 'UTF-8'),
        'page_content' => $pageContent
    ));

    return $template->finish($template->parse('output', 'page'));
}

function RADIO_adminMediaTypeLabel($type)
{
    global $LANG_RADIO;
    $key = 'type_' . (string) $type;
    return isset($LANG_RADIO[$key]) ? $LANG_RADIO[$key] : (string) $type;
}

function RADIO_adminStatusLabel($status)
{
    global $LANG_RADIO;
    $key = (string) $status;
    return isset($LANG_RADIO[$key]) ? $LANG_RADIO[$key] : $key;
}

function RADIO_adminSourceKindLabel($kind)
{
    global $LANG_RADIO;
    return $kind === 'live' ? $LANG_RADIO['source_live'] : $LANG_RADIO['source_external'];
}

function RADIO_adminSyncModeLabel($mode)
{
    global $LANG_RADIO;
    $key = $mode === 'drafts' ? 'feed_sync_drafts' : 'feed_sync_preview';
    return $LANG_RADIO[$key];
}

function RADIO_adminSelectOptions($items, $selected)
{
    $html = '';
    foreach ($items as $value => $label) {
        $html .= '<option value="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '"'
            . ((string) $value === (string) $selected ? ' selected' : '') . '>'
            . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . '</option>';
    }
    return $html;
}

function RADIO_adminMediaTypeOptions($selected, $includeSpecial)
{
    global $LANG_RADIO;
    $types = array('music','podcast','interview','show','chronicle');
    if ($includeSpecial) {
        $types = array_merge($types, array('jingle','announcement','promo'));
    }
    $items = array();
    foreach ($types as $type) {
        $items[$type] = $LANG_RADIO['type_' . $type];
    }
    return RADIO_adminSelectOptions($items, $selected);
}

function RADIO_adminStatusOptions($selected)
{
    global $LANG_RADIO;
    return RADIO_adminSelectOptions(array(
        'draft' => $LANG_RADIO['draft'],
        'published' => $LANG_RADIO['published']
    ), $selected);
}

function RADIO_adminQuickActions()
{
    global $_CONF, $LANG_RADIO;
    if (!SEC_hasRights('radio.upload')) {
        return '';
    }
    $template = RADIO_adminTemplate('quick-actions.thtml');
    $template->set_var(array(
        'quick_actions_title' => htmlspecialchars($LANG_RADIO['admin_quick_actions'], ENT_QUOTES, 'UTF-8'),
        'upload_url' => htmlspecialchars($_CONF['site_admin_url'] . '/plugins/radio/upload.php', ENT_QUOTES, 'UTF-8'),
        'upload_label' => htmlspecialchars($LANG_RADIO['admin_add_audio'], ENT_QUOTES, 'UTF-8'),
        'external_url' => htmlspecialchars($_CONF['site_admin_url'] . '/plugins/radio/external.php', ENT_QUOTES, 'UTF-8'),
        'external_label' => htmlspecialchars($LANG_RADIO['admin_add_external'], ENT_QUOTES, 'UTF-8'),
        'quick_actions_help' => htmlspecialchars($LANG_RADIO['admin_quick_actions_help'], ENT_QUOTES, 'UTF-8')
    ));
    return $template->finish($template->parse('output', 'page'));
}
