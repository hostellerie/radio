<?php
$LANG_RADIO = array(
    'plugin_name' => 'Radio',
    'admin_title' => 'Radio',
    'admin_intro' => 'Gérez la médiathèque audio, les émissions et la programmation.',
    'storage' => 'Stockage persistant',
    'storage_ready' => 'Disponible',
    'storage_unavailable' => 'Indisponible',
    'open_configuration' => 'Ouvrir la configuration de Radio',
    'upload_title' => 'Ajouter un audio',
    'audio_file' => 'Fichier audio',
    'title' => 'Titre',
    'description' => 'Description',
    'type' => 'Type',
    'status' => 'Statut',
    'draft' => 'Brouillon',
    'published' => 'Publié',
    'allow_download' => 'Autoriser le téléchargement',
    'upload' => 'Ajouter l’audio',
    'library' => 'Médiathèque audio',
    'library_empty' => 'La médiathèque audio est vide.',
    'file' => 'Fichier',
    'save' => 'Enregistrer',
    'delete' => 'Supprimer',
    'confirm_delete' => 'Supprimer ce contenu audio et son fichier stocké ?',
    'download' => 'Télécharger',
    'back_to_library' => 'Retour à Radio',
    'public_empty' => 'Aucun contenu audio publié pour le moment.',
    'media_not_found' => 'Ce contenu audio n’est pas disponible.',
    'upload_saved' => 'Le fichier audio a été ajouté.',
    'upload_failed' => 'Le fichier audio n’a pas pu être ajouté.',
    'upload_error' => 'Le téléversement ne s’est pas terminé correctement.',
    'upload_size' => 'Le fichier audio dépasse la taille autorisée ou est vide.',
    'upload_type' => 'Le fichier sélectionné n’est pas dans un format audio accepté.',
    'upload_move' => 'Le fichier n’a pas pu être déplacé vers le stockage persistant de Radio.',
    'database_error' => 'Les métadonnées audio n’ont pas pu être enregistrées.',
    'invalid_token' => 'La requête n’a pas pu être validée. Rechargez la page et recommencez.',
    'access_denied' => 'Vous n’avez pas les droits nécessaires pour cette action Radio.',
    'media_saved' => 'Les métadonnées audio ont été mises à jour.',
    'media_save_failed' => 'Les métadonnées audio n’ont pas pu être mises à jour.',
    'media_deleted' => 'Le contenu audio a été supprimé.',
    'media_delete_failed' => 'Le contenu audio n’a pas pu être supprimé.',
    'type_music' => 'Musique',
    'type_podcast' => 'Podcast',
    'type_interview' => 'Interview',
    'type_show' => 'Émission',
    'type_chronicle' => 'Chronique',
    'type_jingle' => 'Jingle',
    'type_announcement' => 'Annonce',
    'type_promo' => 'Promotion'
);
$LANG_configsections['radio'] = array('label' => 'Radio', 'title' => 'Configuration de Radio');
$LANG_configsubgroups['radio'] = array('sg_main' => 'Paramètres principaux');
$LANG_tab['radio'] = array('tab_main' => 'Principal');
$LANG_fs['radio'] = array('fs_main' => 'Général');
$LANG_confignames['radio'] = array(
    'enabled' => 'Activer Radio ?',
    'public_title' => 'Titre public',
    'default_replay_days' => 'Durée de replay par défaut (jours)',
    'allow_downloads' => 'Autoriser globalement les téléchargements ?',
    'max_upload_mb' => 'Taille maximale d’un fichier audio (Mo)'
);
$LANG_configselects['radio'] = array(0 => array('Activé' => 1, 'Désactivé' => 0));
