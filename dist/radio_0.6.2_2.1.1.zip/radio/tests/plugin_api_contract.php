<?php
$root = dirname(__DIR__);
$functions = file_get_contents($root . '/functions.inc');
$autoinstall = file_get_contents($root . '/autoinstall.php');
$english = file_get_contents($root . '/language/english.php');
$french = file_get_contents($root . '/language/french_france.php');
$defaults = file_get_contents($root . '/install_defaults.php');
$publicIndex = file_get_contents($root . '/public_html/index.php');
$publicProgram = file_get_contents($root . '/public_html/program.php');
$publicReplay = file_get_contents($root . '/public_html/replay.php');
$publicSchedule = file_get_contents($root . '/public_html/schedule.php');
$publicPlayerPage = file_get_contents($root . '/public_html/player.php');
$publicMediaEndpoint = file_get_contents($root . '/public_html/media.php');
$nowEndpoint = file_get_contents($root . '/public_html/now.php');
$publicJs = file_get_contents($root . '/public_html/radio.js');
$publicCss = file_get_contents($root . '/public_html/radio.css');
$adminJs = file_get_contents($root . '/admin/radio-admin.js');
$adminCss = file_get_contents($root . '/admin/radio-admin.css');

$errors = array();

function radio_contract_require($condition, $message)
{
    global $errors;
    if (!$condition) {
        $errors[] = $message;
    }
}

radio_contract_require(
    preg_match('/function\s+plugin_getadminoption_radio\s*\(\s*\)/', $functions) === 1,
    'Missing plugin_getadminoption_radio().'
);
radio_contract_require(
    strpos($functions, "'url' => \$_CONF['site_admin_url'] . '/plugins/radio/index.php'") === false,
    'plugin_getadminoption_radio() must not use the old associative url/text/count return format.'
);
radio_contract_require(
    preg_match(
        '/return\s+array\s*\(\s*\$label\s*,\s*\$_CONF\[\'site_admin_url\'\]\s*\.\s*\'\/plugins\/radio\/index\.php\'\s*,\s*0\s*\)/s',
        $functions
    ) === 1,
    'plugin_getadminoption_radio() must return array(label, url, count).'
);
radio_contract_require(
    preg_match(
        '/function\s+plugin_idtourl_radio\s*\(\s*\$sub_type\s*=\s*\'\'\s*,\s*\$item_id\s*=\s*null\s*\)/',
        $functions
    ) === 1,
    'plugin_idtourl_radio() must support both one-argument and subtype-aware two-argument calls.'
);
radio_contract_require(
    preg_match('/function\s+plugin_chkVersion_radio\s*\(\s*\)/', $functions) === 1,
    'Missing plugin_chkVersion_radio().'
);
radio_contract_require(
    preg_match('/function\s+plugin_upgrade_radio\s*\(\s*\)/', $functions) === 1
        && file_exists($root . '/install_updates.php'),
    'Radio must provide an explicit upgrade path.'
);
radio_contract_require(
    strpos(file_get_contents($root . '/sql/mysql_install.php'), 'on_demand tinyint(1)') !== false
        && strpos(file_get_contents($root . '/sql/mysql_install.php'), 'broadcast tinyint(1)') !== false,
    'Radio media schema must expose on_demand and broadcast availability.'
);
radio_contract_require(
    strpos($functions, 'RADIO_isOnDemandAvailable') !== false
        && strpos($functions, 'RADIO_isBroadcastAvailable') !== false,
    'Radio must expose independent media availability helpers.'
);
radio_contract_require(
    strpos($functions, 'RADIO_mediaAvailabilitySchemaReady') !== false
        && strpos($functions, 'RADIO_mediaAvailabilitySql') !== false,
    'Radio 0.3.0 must remain readable before the availability schema upgrade is applied.'
);
radio_contract_require(
    strpos($functions, "AND on_demand=1") === false
        && strpos($functions, "AND broadcast=1") === false,
    'Radio public/runtime reads must not query 0.3.0 availability columns unconditionally before upgrade.'
);
radio_contract_require(
    strpos($functions, '/radio/live.php') === false,
    'Removed Radio live.php must not be referenced by runtime code.'
);
$programPage = file_get_contents($root . '/public_html/program.php');
radio_contract_require(
    strpos($programPage, '<audio') === false
        && strpos($programPage, 'RADIO_getProgramItems') === false,
    'Public programme pages must stay editorial and must not expose programme media players.'
);
radio_contract_require(
    strpos($programPage, 'RADIO_getProgramUpcomingOccurrences') !== false
        && strpos($programPage, 'RADIO_getProgramReplayOccurrences') !== false,
    'Public programme pages must expose upcoming broadcasts and available replays.'
);
$radioJs = file_get_contents($root . '/public_html/radio.js');
$radioBlockJs = file_get_contents($root . '/public_html/radio-block.js');
radio_contract_require(
    strpos($radioJs, 'endedRetryCount') !== false
        && strpos($radioBlockJs, 'endedRetryCount') !== false,
    'Radio live players must retry synchronization across end-of-track rotation boundaries.'
);
radio_contract_require(
    strpos($radioJs, 'scheduleNextProgrammeTransition') !== false
        && strpos($radioJs, 'expectedProgramId') !== false
        && strpos($radioBlockJs, 'scheduleNextProgrammeTransition') !== false
        && strpos($radioBlockJs, 'expectedProgramId') !== false,
    'Active Radio listeners must hand off scheduled programmes from the beginning.'
);
$uploadAdmin = file_get_contents($root . '/admin/upload.php');
radio_contract_require(
    strpos($uploadAdmin, "ini_get('upload_max_filesize')") !== false
        && strpos($uploadAdmin, "ini_get('post_max_size')") !== false
        && strpos($uploadAdmin, "ini_get('max_file_uploads')") !== false,
    'Radio batch uploader must display the effective PHP upload limits.'
);
$editAdmin = file_get_contents($root . '/admin/edit.php');
$indexAdmin = file_get_contents($root . '/admin/index.php');
radio_contract_require(
    strpos($editAdmin, "/plugins/radio/index.php?updated=1") !== false
        && strpos($indexAdmin, 'isset($_GET[\'updated\'])') !== false,
    'Successful Radio media saves must redirect back to the media library with confirmation.'
);
$adminUi = file_get_contents($root . '/admin/admin-ui.inc.php');
$mediaTable = file_get_contents($root . '/templates/admin/media-list-table.thtml');
radio_contract_require(
    strpos($adminUi, 'return $LANG_RADIO[\'source_local\'];') !== false
        && strpos($adminUi, 'function RADIO_adminSortHeader') !== false
        && strpos($mediaTable, '{modified_header}') !== false,
    'Radio media library must identify local files correctly and expose sortable administrative columns.'
);
$mediaRow = file_get_contents($root . '/templates/admin/media-list-row.thtml');
radio_contract_require(
    strpos($adminUi, 'function RADIO_adminDisplayName') !== false
        && strpos($adminUi, 'rawurldecode') !== false
        && strpos($mediaRow, 'radio-admin__ellipsis') !== false
        && strpos($mediaRow, 'radio-admin__nowrap') !== false,
    'Radio media library must decode imported filenames and keep administrative columns compact.'
);
radio_contract_require(
    strpos($functions, 'function RADIO_validateExternalAudioSource') !== false
        && strpos($functions, 'function RADIO_externalAudioProbeRequest') !== false
        && strpos($functions, 'external_url_not_audio') !== false
        && strpos($functions, 'external_url_no_range') !== false
        && strpos($functions, 'RADIO_validateExternalAudioSource(') !== false,
    'Radio remote sources must be probed and validated before they are saved.'
);
$radioBlockCss = file_get_contents($root . '/public_html/radio-block.css');
radio_contract_require(
    strpos($radioBlockCss, '.radio-block__title') !== false
        && strpos($radioBlockCss, 'overflow-wrap: anywhere') !== false
        && strpos($radioBlockCss, 'word-break: break-word') !== false
        && strpos($radioBlockCss, 'max-width: 100%') !== false
        && strpos($radioBlockCss, 'min-width: 0') !== false,
    'Radio block must stay responsive with long unbroken titles in narrow theme sidebars.'
);
$playerPhp = file_get_contents($root . '/public_html/player.php');
$playerJs = file_get_contents($root . '/public_html/radio-player.js');
$publicIndex = file_get_contents($root . '/public_html/index.php');
radio_contract_require(
    strpos($playerPhp, 'data-radio-player') !== false
        && strpos($playerJs, "body.set('source', 'persistent')") !== false
        && strpos($playerJs, 'data-autoplay') !== false
        && strpos($publicIndex, 'data-radio-persistent-player') !== false
        && strpos($functions, "'persistent'") !== false
        && strpos($functions, '/radio/player.php?autoplay=1') !== false,
    'Radio must expose a persistent detached player that follows live state across site navigation.'
);
radio_contract_require(
    strpos($functions, 'function RADIO_cleanImportedTitle') !== false
        && strpos($functions, 'rawurldecode') !== false
        && strpos($functions, 'official video') !== false
        && strpos($functions, '[A-Za-z0-9_-]{11}') !== false
        && strpos($functions, 'RADIO_normalizeImportedMediaTitle') !== false,
    'Radio must clean auto-generated imported track titles without rewriting manual editorial titles.'
);
$publicPlayer = file_get_contents($root . '/public_html/radio.js');
$blockPlayer = file_get_contents($root . '/public_html/radio-block.js');
$persistentPlayer = file_get_contents($root . '/public_html/radio-player.js');
radio_contract_require(
    strpos($publicPlayer, 'fromEnded && nextId !== endedMediaId && nextProgram === programId') !== false
        && strpos($blockPlayer, 'fromEnded && nextMediaId !== endedMediaId && nextProgramId === programId') !== false
        && strpos($persistentPlayer, 'fromEnded && nextMediaId !== endedMediaId && nextProgramId === programId') !== false,
    'Radio players must start the next item at zero after a natural end within the same broadcast context.'
);

$defaults = file_get_contents($root . '/install_defaults.php');
$nowEndpoint = file_get_contents($root . '/public_html/now.php');
$studioLog = file_get_contents($root . '/lib/studio-log.inc.php');
radio_contract_require(
    strpos($defaults, "'debug_logging' => 0") !== false
        && strpos($english, "'debug_logging' => 'Enable debug logging?'") !== false
        && strpos($french, "'debug_logging' => 'Activer les journaux de débogage ?'") !== false
        && strpos($studioLog, "\$debugEnabled = !empty(\$_RADIO_CONF['debug_logging']);") !== false
        && strpos($studioLog, "array('WARNING', 'ERROR')") !== false,
    'Radio debug logging must be disabled by default while warnings and errors remain logged.'
);

radio_contract_require(
    strpos($defaults, "'transition_mode' => 'gapless'") !== false
        && strpos($defaults, "'crossfade_seconds' => 2") !== false
        && strpos($functions, 'function RADIO_transitionOverlap') !== false
        && strpos($functions, "\$currentType === 'music' && \$nextType === 'music'") !== false
        && strpos($nowEndpoint, "'next_media'") !== false
        && strpos($nowEndpoint, "'transition_seconds'") !== false
        && strpos($publicPlayer, "currentType === 'jingle'") !== false
        && strpos($publicPlayer, "fadeSeconds = jingleIntoMusic ? 0.7 : seconds") !== false,
    'Radio must expose configurable music-to-music crossfade and preserve complete jingles while blending the following music in client-side.'
);

$versionFile = file_get_contents($root . '/version.php');
$updatesFile = file_get_contents($root . '/install_updates.php');
radio_contract_require(
    strpos($defaults, "strpos(\$name, 'shared_library_') === 0") !== false
        && strpos($defaults, "\$c->del(\$name, 'radio');") !== false,
    'Radio configuration reconciliation must remove obsolete shared_library_* settings from development installations.'
);

radio_contract_require(
    strpos($versionFile, "RADIO_PLUGIN_VERSION', '0.6.2") !== false
        && strpos($updatesFile, "'0.3.0' => array(") !== false
        && strpos($updatesFile, "'next' => '0.3.1'") !== false
        && strpos($updatesFile, 'radio_update_0_3_0_to_0_3_1') !== false
        && strpos($updatesFile, "'0.3.1' => array(") !== false
        && strpos($updatesFile, "'next' => '0.3.2'") !== false
        && strpos($updatesFile, 'radio_update_0_3_1_to_0_3_2') !== false
        && strpos($updatesFile, "'0.3.2' => array(") !== false
        && strpos($updatesFile, "'next' => '0.4.0'") !== false
        && strpos($updatesFile, 'radio_update_0_3_2_to_0_4_0') !== false
        && strpos($updatesFile, "'0.4.0' => array(") !== false
        && strpos($updatesFile, "'next' => '0.5.0'") !== false
        && strpos($updatesFile, 'radio_update_0_4_0_to_0_5_0') !== false
        && strpos($updatesFile, "'0.5.0' => array(") !== false
        && strpos($updatesFile, "'next' => '0.5.1'") !== false
        && strpos($updatesFile, 'radio_update_0_5_0_to_0_5_1') !== false
        && strpos($updatesFile, "'0.5.1' => array(") !== false
        && strpos($updatesFile, "'next' => '0.6.0'") !== false
        && strpos($updatesFile, 'radio_update_0_5_1_to_0_6_0') !== false
        && strpos($updatesFile, "'0.6.0' => array(") !== false
        && strpos($updatesFile, "'next' => '0.6.1'") !== false
        && strpos($updatesFile, 'radio_update_0_6_0_to_0_6_1') !== false
        && strpos($updatesFile, "'0.6.1' => array(") !== false
        && strpos($updatesFile, "'next' => '0.6.2'") !== false
        && strpos($updatesFile, 'radio_update_0_6_1_to_0_6_2') !== false
        && strpos($functions, 'RADIO_ensureConfig()') !== false,
    'Radio 0.6.2 must preserve the existing upgrade chain through 0.6.1 and reconcile configuration during upgrade.'
);

$mysqlInstall = file_get_contents($root . '/sql/mysql_install.php');
$mediaEditTemplate = file_get_contents($root . '/templates/admin/media-edit.thtml');
$mediaUploadTemplate = file_get_contents($root . '/templates/admin/media-upload.thtml');
radio_contract_require(
    strpos($mysqlInstall, 'automatic_rotation tinyint(1) unsigned NOT NULL default \'1\'') !== false
        && strpos($functions, "RADIO_mediaAvailabilitySql('automatic_rotation', '')") !== false
        && strpos($functions, "['automatic_rotation']") !== false
        && strpos($functions, "\$reasons[] = 'automatic_rotation'") !== false
        && strpos($mediaEditTemplate, 'name="automatic_rotation"') !== false
        && strpos($mediaUploadTemplate, 'name="automatic_rotation"') !== false,
    'Radio 0.3.2 must let broadcast media opt out of automatic rotation while remaining usable in programmes.'
);

$mediaFilterTemplate = file_get_contents($root . '/templates/admin/media-filters.thtml');
radio_contract_require(
    strpos($mysqlInstall, 'category varchar(128)') !== false
        && strpos($mysqlInstall, 'collection_name varchar(255)') !== false
        && strpos($mysqlInstall, 'tags text') !== false
        && strpos($functions, 'function RADIO_normalizeTags') !== false
        && strpos($functions, 'function RADIO_mediaClassificationOptions') !== false
        && strpos($functions, 'function RADIO_mediaClassificationSchemaReady') !== false
        && strpos($functions, "FIND_IN_SET('") !== false
        && strpos($mediaEditTemplate, 'name="category"') !== false
        && strpos($mediaEditTemplate, 'name="collection_name"') !== false
        && strpos($mediaEditTemplate, 'name="tags"') !== false
        && strpos($mediaFilterTemplate, 'name="category"') !== false
        && strpos($mediaFilterTemplate, 'name="collection"') !== false
        && strpos($mediaFilterTemplate, 'name="tag"') !== false,
    'Radio 0.4.0 must provide category, collection and tag classification with combined media-library filters.'
);

$programAdmin = file_get_contents($root . '/admin/programs.php');
$rotationAdmin = file_get_contents($root . '/admin/rotation.php');
$studioPage = file_get_contents($root . '/admin/studio.php');
$studioApi = file_get_contents($root . '/admin/studio-api.php');
$studioStream = file_get_contents($root . '/admin/studio-stream.php');
$studioJs = file_get_contents($root . '/admin/radio-studio.js');
$studioOutput = file_get_contents($root . '/lib/studio-output.inc.php');
$studioLive = file_get_contents($root . '/lib/studio-live.inc.php');
$youtubeLib = file_get_contents($root . '/lib/youtube.inc.php');
$legacyPreview = file_get_contents($root . '/admin/preview.php');

radio_contract_require(
    strpos($studioStream, "require_once dirname(__FILE__) . '/../../../lib-common.php';") !== false
        && strpos($studioStream, "require_once dirname(__FILE__) . '/../../auth.inc.php';") === false
        && strpos($studioStream, "require_once \$_CONF['path'] . 'plugins/radio/lib/studio-output.inc.php';") !== false
        && strpos($studioStream, "require_once \$_CONF['path'] . 'plugins/radio/lib/studio-live.inc.php';") !== false
        && strpos($studioApi, "require_once dirname(__FILE__) . '/../../../lib-common.php';") !== false
        && strpos($studioApi, "require_once \$_CONF['path'] . 'plugins/radio/lib/studio-log.inc.php';") !== false
        && strpos($studioStream, "require_once \$_CONF['path'] . 'plugins/radio/lib/studio-log.inc.php';") !== false
        && strpos($studioApi, "require_once dirname(__FILE__) . '/../../auth.inc.php';") === false
        && strpos($studioApi, "require_once \$_CONF['path'] . 'plugins/radio/lib/studio-live.inc.php';") === false
        && strpos($studioApi, "require_once \$_CONF['path'] . 'plugins/radio/lib/studio-output.inc.php';") === false,
    'Radio Studio editorial and realtime JSON endpoints must bypass Geeklog admin/auth.inc.php; only the realtime endpoint loads output/live helpers.'
);

radio_contract_require(
    strpos($programAdmin, 'RADIO_adminRenderProgramMediaPicker') === false
        && strpos($programAdmin, 'RADIO_addProgramItem') === false
        && strpos($programAdmin, 'RADIO_removeProgramItem') === false
        && strpos($programAdmin, 'RADIO_moveProgramItem') === false
        && strpos($programAdmin, '/plugins/radio/studio.php?program_id=') !== false,
    'Radio programme administration must stay metadata-only and link to the Studio for playlist editing.'
);

radio_contract_require(
    strpos($studioPage, "SEC_hasRights('radio.schedule')") !== false
        && strpos($studioPage, 'RADIO_getProgramItems') !== false
        && strpos($studioPage, 'RADIO_isBroadcastAvailable') !== false
        && strpos($studioPage, 'data-radio-replay-player') !== false
        && strpos($studioPage, 'data-radio-replay-chapter') !== false
        && strpos($studioPage, 'radio-studio__queue') !== false
        && strpos($studioPage, 'radio-program-picker__filters') !== false
        && strpos($studioPage, "RADIO_mediaUrl((int) \$item['media_id'], false)") !== false,
    'Radio Studio must provide private continuous preview, a server-rendered queue and media search.'
);

radio_contract_require(
    strpos($publicJs, 'context.createMediaStreamDestination()') !== false
        && strpos($publicJs, 'masterLimiter.connect(captureDestination)') !== false
        && strpos($publicJs, 'root.radioStudioMaster') !== false
        && strpos($publicJs, 'getMasterStream') !== false,
    'Radio Studio must expose one post-limiter master capture bus without replacing local monitoring.'
);

radio_contract_require(
    strpos($studioPage, '<audio data-radio-replay-audio preload="none"></audio>') !== false
        && strpos($publicJs, "var lazyStudio = trackingSource === 'studio';") !== false
        && strpos($publicJs, 'var studioActivated = !lazyStudio;') !== false
        && strpos($publicJs, 'if (lazyStudio && !studioActivated)') !== false
        && strpos($studioApi, '@session_write_close();') !== false
        && strpos($studioStream, '@session_write_close();') !== false,
    'Radio Studio must lazy-load media until first Play and release Geeklog session locks before JSON work.'
);

radio_contract_require(
    strpos($studioPage, 'data-radio-studio-record') !== false
        && strpos($studioJs, "studio_action', 'recording_start'") !== false
        && strpos($studioJs, "recordingRecorder.start(2000)") !== false
        && strpos($studioStream, "if (\$action === 'recording_chunk')") !== false
        && strpos($studioApi, "realtime_endpoint_moved") !== false
        && strpos($studioOutput, 'function RADIO_studioRecordingAppend') !== false
        && strpos($studioOutput, 'function RADIO_studioRecordingCleanupStale') !== false
        && strpos($studioOutput, 'RADIO_studioRecordingCleanupStale(21600)') !== false
        && strpos($studioOutput, "'last_chunk_at' => ''") !== false
        && strpos($studioOutput, "\$meta['last_chunk_at'] = date('Y-m-d H:i:s')") !== false
        && strpos($studioOutput, "\$activityAt = \$lastChunkAt !== false ? \$lastChunkAt : \$startedAt") !== false
        && strpos($studioOutput, "'abort_reason'] = 'stale_session_timeout'") !== false
        && strpos($studioOutput, "RADIO_studioSiteStorageDir") !== false,
    'Radio Studio recording must capture the master mix through bounded authenticated chunks into site-specific persistent storage.'
);

radio_contract_require(
    strpos($studioPage, 'data-radio-studio-youtube') !== false
        && strpos($studioPage, 'data-radio-studio-stream-endpoint') !== false
        && strpos($studioPage, '/plugins/radio/studio-stream.php?program_id=') !== false
        && strpos($studioJs, "studio.getAttribute('data-radio-studio-stream-endpoint')") !== false
        && strpos($studioJs, "studio_action', 'youtube_live_start'") !== false
        && strpos($studioJs, "youtubeLiveRecorder.start(1000)") !== false
        && strpos($studioJs, "studio_action', 'youtube_live_chunk'") !== false
        && strpos($studioJs, "studio_action', 'youtube_live_stop'") !== false
        && strpos($studioJs, "studioUrl('live_status', {}, streamEndpoint)") !== false
        && strpos($studioStream, "if (\$action === 'youtube_live_start')") !== false
        && strpos($studioStream, "if (\$action === 'youtube_live_chunk')") !== false
        && strpos($studioStream, "if (\$action === 'youtube_live_stop')") !== false
        && strpos($studioStream, "if (\$_SERVER['REQUEST_METHOD'] === 'GET' && \$action === 'live_status')") !== false
        && strpos($studioApi, "realtime_endpoint_moved") !== false
        && strpos($studioLive, 'function RADIO_studioYoutubeStart') !== false
        && strpos($studioLive, 'function RADIO_studioYoutubeAppend') !== false
        && strpos($studioLive, 'function RADIO_studioYoutubeCleanupStale') !== false
        && strpos($studioLive, 'function RADIO_studioYoutubeFindFfmpeg') !== false
        && strpos($studioLive, "RADIO_youtubeStatus()") !== false
        && strpos($studioLive, "['ffmpeg_path']") !== false
        && strpos($studioLive, "Known CLI path=") !== false
        && strpos($studioLive, 'function RADIO_studioYoutubeStopEncoder') !== false
        && strpos($studioLive, "'tail -c +1 -F '") !== false
        && strpos($studioLive, "'nohup setsid sh -c '") !== false
        && strpos($studioLive, 'RADIO_youtubeStudioFfmpegCommand') !== false
        && strpos($studioLive, 'RADIO_studioYoutubeFindPhpCli') === false
        && strpos($youtubeLib, 'function RADIO_youtubeStudioFfmpegCommand') !== false
        && !is_file($root . '/bin/studio-youtube-live.php'),
    'Radio Studio YouTube Live must use the dedicated realtime endpoint and one detached tail-to-FFmpeg process group without a second PHP/Geeklog worker.'
);

radio_contract_require(
    strpos($functions, '<script id="radio-public-js" defer src="') !== false
        && strpos($studioPage, '$content .= $studioSimpleScript;') !== false,
    'Radio public controls must be deferred and the minimal Studio helper must be appended after its markup.'
);

radio_contract_require(
    strpos($studioJs, 'stateRequestInFlight') !== false
        && strpos($studioJs, 'function statePollDelay()') !== false
        && strpos($studioJs, 'function scheduleStatePoll(delay)') !== false
        && strpos($studioJs, 'document.hidden') !== false
        && strpos($studioJs, 'return 120000;') !== false
        && strpos($studioJs, 'broadcastActive ? 30000 : 60000') !== false
        && strpos($studioJs, 'Math.random()') !== false
        && strpos($studioJs, 'window.setTimeout(function ()') !== false
        && strpos($studioJs, 'window.setInterval(syncState, 3000)') === false,
    'Radio Studio state polling must remain a sparse single-flight safety sync, independent from audio continuity.'
);

radio_contract_require(
    strpos($studioPage, 'data-radio-studio-endpoint') !== false
        && strpos($studioPage, 'data-radio-studio-mutation-endpoint') !== false
        && strpos($studioPage, 'data-radio-studio-queue') !== false
        && strpos($studioPage, 'data-radio-studio-search') !== false
        && strpos($studioPage, 'data-radio-studio-results') !== false
        && strpos($studioPage, 'radio-studio.js') !== false
        && strpos($studioApi, 'function radio_studio_check_token') !== false
        && strpos($studioApi, "if (\$studioAction === 'remove')") !== false
        && strpos($studioApi, "if (\$studioAction === 'move_up' || \$studioAction === 'move_down')") !== false
        && strpos($studioJs, "body.set('studio_action', 'add')") !== false
        && strpos($studioJs, 'function bindStudioActionDelegation') !== false
        && strpos($studioJs, "mutateItem(action, itemId)") !== false,
    'Radio Studio mutations must use live AJAX updates without reloading the playing Studio page.'
);

radio_contract_require(
    strpos($mysqlInstall, 'radio_broadcast_sessions') !== false
        && strpos($functions, "['radio_broadcast_sessions']") !== false
        && strpos($functions, 'function RADIO_startBroadcastSession') !== false
        && strpos($functions, 'function RADIO_stopBroadcastSession') !== false
        && strpos($functions, 'function RADIO_resolveBroadcastSession') !== false
        && strpos($functions, "'source' => 'semi-live'") !== false
        && strpos($studioApi, "if (\$studioAction === 'broadcast_start')") !== false
        && strpos($studioApi, "if (\$studioAction === 'broadcast_stop')") !== false
        && strpos($studioPage, 'data-radio-studio-broadcast') !== false
        && strpos($studioJs, "studio_action', broadcastActive ? 'broadcast_stop' : 'broadcast_start'") !== false,
    'Radio 0.6.1 Studio must preserve server-driven semi-live broadcast sessions without relying on the operator browser as the broadcast clock.'
);

radio_contract_require(
    strpos($studioPage, 'radio-studio__player-meta') !== false
        && strpos($studioPage, 'radio-studio__buffer-status') !== false
        && strpos($studioPage, 'data-radio-studio-buffer') !== false
        && strpos($adminCss, '.radio-studio__buffer-status') !== false,
    'Radio Studio buffer diagnostics must be displayed below the player with dedicated styling.'
);

radio_contract_require(
    strpos($functions, 'function RADIO_normalizeProgramItemOrder') !== false
        && strpos($functions, 'function RADIO_addProgramItem($programId, $mediaId, $afterItemId = 0)') !== false
        && strpos($studioJs, "body.set('position', position)") !== false
        && strpos($studioJs, "player.getAttribute('data-radio-current-item-id')") !== false
        && strpos($studioJs, 'dispatchPlaylist(data.items || [])') !== false
        && strpos($publicPlayer, "root.addEventListener('radio:seek-item'") !== false,
    'Radio Studio must preserve Play next and live queue navigation while audio keeps playing.'
);

radio_contract_require(
    strpos($studioPage, 'radio-studio__queue-type') !== false
        && strpos($studioPage, 'radio-studio__queue-duration') !== false
        && strpos($studioPage, 'radio-studio__queue-title radio-studio__queue-seek') !== false
        && strpos($studioJs, "type.className = 'radio-admin__badge radio-studio__queue-type'") !== false
        && strpos($studioJs, "duration.className = 'radio-studio__queue-duration'") !== false,
    'Radio Studio programme queue must render type and duration before the left-aligned media title and actions.'
);

radio_contract_require(
    strpos($publicPlayer, 'function itemPlayable') !== false
        && strpos($publicPlayer, 'function nextPlayableIndex') !== false
        && strpos($publicPlayer, 'function totalDuration') !== false
        && strpos($publicPlayer, 'function seekGlobal') !== false
        && strpos($publicPlayer, 'parseFloat(seconds || 0)') !== false
        && strpos($publicPlayer, 'var followingIndex = nextPlayableIndex(index + 1)') !== false
        && strpos($publicPlayer, 'if (audio.ended || !itemPlayable(index))') !== false,
    'Radio Studio Listen must traverse all playable programme items and global navigation must seek across the full programme timeline.'
);

radio_contract_require(
    strpos($publicPlayer, 'queuePreload.currentTime = 0;') !== false
        && strpos($publicPlayer, "String(items[index].media_type || '') === 'jingle'") !== false
        && strpos($publicPlayer, "String(next.media_type || '') === 'music'") !== false
        && strpos($publicPlayer, 'return 0.7;') !== false
        && strpos($publicPlayer, 'audio.volume = jingleIntoMusic ? 1 : (1 - progressValue);') !== false,
    'Radio Studio must restart fallback-preloaded items at zero and blend music under a complete jingle.'
);

radio_contract_require(
    strpos($publicPlayer, 'prepare: function ()') !== false
        && strpos($publicPlayer, 'studioFx.prepare();') !== false
        && strpos($publicPlayer, "initialType === 'jingle'") !== false
        && strpos($publicPlayer, "audio.preload = 'auto';") !== false,
    'Radio Studio must initialize its Web Audio graph before first playback and eagerly preload a short/current jingle.'
);

radio_contract_require(
    strpos($functions, '$selectedMediaIds = array();') !== false
        && strpos($functions, "if (\$mediaType === 'jingle')") !== false
        && strpos($functions, '$pendingJingle = $item;') !== false
        && strpos($functions, 'isset($selectedMediaIds[$mediaId])') !== false
        && strpos($functions, '$selectedMediaIds[$mediaId] = true;') !== false
        && strpos($functions, '$lastJingleMediaId') !== false
        && strpos($functions, 'count($jinglePool) > 1') !== false
        && strpos($functions, '$addedRegularThisCycle === 0') !== false,
    'Generated Radio programmes must keep regular media unique, allow controlled jingle reuse, preserve rotation alternation and stop instead of padding with orphan jingles.'
);

radio_contract_require(
    strpos($publicPlayer, 'function applyProgrammeDuck()') !== false
        && strpos($publicPlayer, 'function releaseProgrammeDuck()') !== false
        && strpos($publicPlayer, 'promise.then(function ()') !== false
        && strpos($publicPlayer, 'applyProgrammeDuck();') !== false
        && strpos($publicPlayer, 'sample.audio.onerror = releaseProgrammeDuck;') !== false,
    'Studio pad jingles must duck the programme only after playback has actually started and restore it on failure/end.'
);

radio_contract_require(
    strpos($publicPlayer, 'function bufferedQueueElementFor') !== false
        && strpos($publicPlayer, 'function activateBufferedQueueItem') !== false
        && strpos($publicPlayer, "setItem(seekIndex, 0, true);") !== false
        && strpos($publicPlayer, "queueBufferedAhead(queuePreload) > 0") !== false
        && strpos($publicPlayer, "queueBufferedAhead(queueReserve) > 0") !== false,
    'Radio Studio manual track selection must start immediately and reuse already-buffered preload/reserve audio.'
);

radio_contract_require(
    strpos($publicPlayer, 'function promoteQueuePreload') !== false
        && strpos($publicPlayer, 'queuePreload.readyState < 2') !== false
        && strpos($publicPlayer, 'if (promoteQueuePreload(followingIndex))') !== false,
    'Radio Studio must promote an already-buffered next item at ended transitions instead of reloading it.'
);

radio_contract_require(
    strpos($publicPlayer, 'function finishQueueTransitionAtEnded') !== false
        && strpos($publicPlayer, 'if (followingIndex >= 0 && queueMixing)') !== false
        && strpos($publicPlayer, 'window.cancelAnimationFrame(queueFadeFrame)') !== false
        && strpos($publicPlayer, 'finishQueueTransitionAtEnded(followingIndex)') !== false,
    'Radio Studio must finalize an in-progress crossfade when the current track ends instead of freezing while queueMixing stays active.'
);

radio_contract_require(
    strpos($publicPlayer, 'function forceQueueHandoffIfNeeded') !== false
        && strpos($publicPlayer, 'window.setInterval(monitorQueueTransition, 100)') !== false
        && strpos($publicPlayer, 'isFinite(audio.duration)') !== false
        && strpos($publicPlayer, 'remaining > 0.18') !== false,
    'Radio Studio must use decoded media duration plus a high-frequency transition watchdog to prevent end-of-track gaps when timeupdate is sparse or metadata duration differs.'
);

radio_contract_require(
    strpos($studioPage, 'data-radio-studio-djfx') !== false
        && strpos($studioPage, 'data-radio-djfx="low"') !== false
        && strpos($studioPage, 'data-radio-djfx="mid"') !== false
        && strpos($studioPage, 'data-radio-djfx="high"') !== false
        && strpos($studioPage, 'data-radio-djfx="filter"') !== false
        && strpos($studioPage, 'data-radio-djfx-value="low"') !== false
        && strpos($studioPage, 'data-radio-djfx-button="echo"') !== false
        && strpos($studioPage, 'radio-studio__djfx-pad-trigger') !== false
        && strpos($studioPage, 'data-radio-djfx-pad-select="1"') !== false
        && strpos($studioPage, 'data-radio-djfx-pad-play="4"') !== false,
    'Radio Studio must expose touch-friendly realtime DJ FX controls with live values and assignable jingle pads.'
);

radio_contract_require(
    strpos($publicPlayer, "root.addEventListener('radio:djfx'") !== false
        && strpos($publicPlayer, "context.createBiquadFilter()") !== false
        && strpos($publicPlayer, "context.createDelay(1.0)") !== false
        && strpos($publicPlayer, "function assignSample") !== false
        && strpos($publicPlayer, "function playSample") !== false
        && strpos($studioJs, "dispatchDjFx") !== false
        && strpos($studioJs, "radio.djfx.pads.") !== false,
    'Radio Studio DJ FX must use the Web Audio API for realtime EQ/filter/echo and persistent assignable jingle pads.'
);

radio_contract_require(
    strpos($publicPlayer, "type === 'jingle'") !== false
        && strpos($publicPlayer, "reserveType === 'jingle'") !== false
        && strpos($publicPlayer, "queueReserve.preload = reserveType === 'jingle'") !== false,
    'Radio Studio must preload jingles early regardless of the generic short-item duration threshold.'
);

radio_contract_require(
    strpos($publicPlayer, 'function maintainQueueBuffers') !== false
        && strpos($publicPlayer, 'window.setInterval(maintainQueueBuffers, 10000)') !== false
        && strpos($publicPlayer, 'function advanceQueueAudioRole') !== false
        && strpos($publicPlayer, 'queuePreload = bufferedReserve') !== false
        && strpos($publicPlayer, 'queueReserve = previousAudio') !== false,
    'Radio Studio must keep N+1/N+2 buffers warm during long tracks and rotate the buffered reserve forward without discarding it.'
);

radio_contract_require(
    strpos($legacyPreview, '/plugins/radio/studio.php') !== false
        && strpos($legacyPreview, "header('Location: ' . \$url, true, 302)") !== false,
    'Legacy preview.php URLs must redirect to the canonical Studio page.'
);

radio_contract_require(
    strpos($publicPlayer, 'queuePreload = new Audio()') !== false
        && strpos($publicPlayer, 'queueReserve = new Audio()') !== false,
    'Radio replay player must keep N+1/N+2 prebuffering support.'
);

radio_contract_require(
    strpos($functions, 'function RADIO_rebuildRotationNow') !== false
        && strpos($rotationAdmin, "name=\"rebuild_rotation\"") !== false
        && strpos($rotationAdmin, 'SEC_checkToken()') !== false
        && strpos($rotationAdmin, 'RADIO_rebuildRotationNow(time())') !== false,
    'Radio rotation administration must provide an explicit CSRF-protected immediate rebuild control.'
);

radio_contract_require(
    strpos($functions, 'function RADIO_rotationSnapshotSignature') !== false
        && strpos($functions, 'function RADIO_loadRotationSnapshot') !== false
        && strpos($functions, 'function RADIO_saveRotationSnapshot') !== false
        && strpos($functions, 'function RADIO_rotationCycleState') !== false
        && strpos($functions, 'function RADIO_rotationSnapshotItem') !== false
        && strpos($functions, 'function RADIO_transitionOverlapFor') !== false
        && strpos($functions, "'cycle_start'") !== false
        && strpos($functions, "'cycle_duration'") !== false
        && strpos($functions, "'transition_mode'") !== false
        && strpos($functions, "'crossfade_seconds'") !== false
        && strpos($functions, "'items' => \$items") !== false
        && strpos($functions, 'SELECT media_id,status') !== false
        && strpos($functions, 'RADIO_buildFreshRotationSequence') !== false,
    'Radio automatic rotation must freeze the active cycle and only let deletion or leaving published state affect it before the next cycle.'
);
$replayPage = file_get_contents($root . '/public_html/replay.php');
radio_contract_require(
    strpos($replayPage, 'data-radio-replay-player') !== false
        && strpos($replayPage, 'data-radio-replay-items') !== false
        && strpos($replayPage, 'data-radio-replay-progress') !== false
        && strpos($replayPage, 'data-radio-replay-chapter') !== false
        && strpos($publicPlayer, 'function initReplayPlayers') !== false
        && strpos($publicPlayer, "audio.addEventListener('ended'") !== false
        && strpos($publicPlayer, 'seekGlobal') !== false,
    'Radio replay must play a programme continuously with global progress and chapter navigation.'
);

radio_contract_require(
    strpos($functions, "if (count(\$jingles) > 0)") !== false
        && strpos($functions, "\$sequence[] = \$jingles[0]") !== false
        && strpos($functions, "\$jingleIndex = 1") !== false,
    'Every new Radio fallback rotation cycle must start with a jingle when one is available.'
);

radio_contract_require(
    strpos($functions, "RADIO_buildFreshRotationSequence(\$date, \$cycleStart)") !== false
        && strpos($functions, "microtime(true)") !== false
        && strpos($functions, "'next_next_media'") !== false
        && strpos($nowEndpoint, "'next_next_media'") !== false,
    'Each protected Radio rotation cycle must receive a fresh order and live state must continue to expose N+2 for Studio/replay consumers.'
);

radio_contract_require(
    strpos($publicPlayer, "var standby = new Audio()") !== false
        && strpos($blockPlayer, "var standby = new Audio()") !== false
        && strpos($persistentPlayer, "var standby = new Audio()") !== false
        && strpos($publicPlayer, 'bufferedAhead(standby)') !== false
        && strpos($blockPlayer, 'armPreload(false)') !== false
        && strpos($persistentPlayer, 'armPreload(false)') !== false
        && strpos($publicPlayer, 'var promoted = standby;') !== false
        && strpos($publicPlayer, 'standby = previous;') !== false
        && strpos($publicPlayer, "currentType === 'jingle'") !== false,
    'Radio public live players must use bandwidth-conscious A/B N+1 buffering, promote the preloaded element without reloading it, and preserve complete jingles.'
);

radio_contract_require(
    strpos($publicPlayer, 'queuePreload = new Audio()') !== false
        && strpos($publicPlayer, 'queueReserve = new Audio()') !== false,
    'Radio programme preview player must preserve N+1/N+2 prebuffering.'
);

radio_contract_require(
    strpos($studioPage, 'data-radio-transition-mode=') !== false
        && strpos($studioPage, 'data-radio-crossfade-seconds=') !== false
        && strpos($studioPage, "'transition_overlap'") !== false
        && strpos($publicJs, 'function startQueueCrossfade') !== false
        && strpos($publicJs, "transitionMode !== 'crossfade'") !== false
        && strpos($publicJs, 'queuePreload.play()') !== false,
    'Radio Studio preview must apply configured programme crossfade timing.'
);

radio_contract_require(
    strpos($publicJs, 'function advanceQueueAudioRole') !== false
        && strpos($publicJs, 'audio = queuePreload;') !== false
        && strpos($publicJs, 'queuePreload = bufferedReserve;') !== false
        && strpos($publicJs, 'queueReserve = previousAudio;') !== false
        && strpos($publicJs, 'event.currentTarget !== audio') !== false,
    'Radio Studio crossfade handoff must promote the already-playing preload without reloading or seeking the MP3.'
);

radio_contract_require(
    strpos($publicPlayer, 'function createTransitionManager') !== false
        && strpos($blockPlayer, 'function createTransitionManager') !== false
        && strpos($persistentPlayer, 'function createTransitionManager') !== false
        && strpos($publicPlayer, "mode !== 'crossfade'") !== false
        && strpos($blockPlayer, "mode === 'gapless' || mode === 'crossfade'") !== false
        && strpos($persistentPlayer, "standby.preload = 'metadata'") !== false
        && strpos($persistentPlayer, "standby.preload = 'auto'") !== false,
    'All Radio live players must use deferred N+1 preload and apply the configured transition mode.'
);
radio_contract_require(
    strpos($radioJs, 'syncSequence') === false
        && strpos($radioJs, 'intentVersion') === false,
    'Radio home player must not reference undeclared live-page synchronization state.'
);
radio_contract_require(
    strpos($functions, 'function RADIO_isDatabaseCurrent') !== false
        && strpos($functions, 'function plugin_collectSitemapItems_radio') !== false
        && strpos($functions, 'if (!RADIO_isDatabaseCurrent())') !== false,
    'Radio external integrations must stay inactive until the database upgrade is complete.'
);
$searchStart = strpos($functions, 'function plugin_dopluginsearch_radio');
$searchEnd = strpos($functions, 'function plugin_whatsnewsupported_radio', $searchStart);
$searchBlock = ($searchStart !== false && $searchEnd !== false)
    ? substr($functions, $searchStart, $searchEnd - $searchStart)
    : '';
radio_contract_require(
    $searchBlock !== ''
        && strpos($searchBlock, 'UNION ALL') === false
        && substr_count($searchBlock, 'new SearchCriteria') >= 2,
    'Radio search must use separate simple SearchCriteria queries for media and programmes.'
);
radio_contract_require(
    preg_match('/function\s+plugin_wsEnabled_radio\s*\(\s*\)/', $functions) === 1,
    'Missing plugin_wsEnabled_radio().'
);
radio_contract_require(
    preg_match('/function\s+plugin_getcapabilities_radio\s*\(\s*\)/', $functions) === 1,
    'Missing plugin_getcapabilities_radio().'
);
radio_contract_require(
    preg_match('/function\s+RADIO_singleItemInfoResult\s*\(/', $functions) === 1,
    'Radio must map single Item Info responses to Geeklog positional values.'
);
radio_contract_require(
    strpos($functions, 'return RADIO_singleItemInfoResult(') !== false,
    'Single Radio Item Info responses must use Geeklog positional mapping.'
);
radio_contract_require(
    preg_match('/function\s+plugin_getheadercode_radio\s*\(\s*\)/', $functions) === 1,
    'Missing plugin_getheadercode_radio().'
);
radio_contract_require(
    strpos($functions, "RADIO_PLUGIN_VERSION") !== false
        && strpos($functions, "filemtime") !== false
        && strpos($functions, "radio-admin.css") !== false,
    'Radio admin CSS must be versioned with plugin version and file modification time.'
);
radio_contract_require(
    preg_match('/function\s+plugin_autoinstall_radio\s*\(\s*\$pi_name\s*\)/', $autoinstall) === 1,
    'Missing plugin_autoinstall_radio($pi_name).'
);
radio_contract_require(
    preg_match('/function\s+plugin_autouninstall_radio\s*\(\s*\)/', $autoinstall) === 1,
    'Missing plugin_autouninstall_radio().'
);
radio_contract_require(
    strpos($functions, "require_once __DIR__ . '/autoinstall.php';") !== false,
    'functions.inc must load autoinstall.php so Geeklog can discover plugin_autouninstall_radio() for disabled plugins.'
);
radio_contract_require(
    strpos($autoinstall, "require_once __DIR__ . '/functions.inc';") === false,
    'autoinstall.php must not create a circular functions.inc dependency.'
);
radio_contract_require(
    strpos($functions, "\$radioLanguageFile = __DIR__ . '/language/' . \$radioLanguage . '.php';") !== false,
    'functions.inc must bootstrap the Radio language file.'
);
radio_contract_require(
    strpos($functions, "language/english.php") !== false,
    'Radio language bootstrap must provide an English fallback.'
);
radio_contract_require(
    strpos($functions, 'global $_CONF, $_TABLES, $_DB_table_prefix, $_RADIO_CONF, $LANG_RADIO;') !== false,
    'functions.inc must declare Geeklog globals before language bootstrap.'
);
foreach (array('english' => $english, 'french' => $french) as $languageName => $languageFile) {
    radio_contract_require(
        strpos($languageFile, 'global $LANG_RADIO, $LANG_configsections, $LANG_confignames, $LANG_configsubgroups, $LANG_tab, $LANG_fs, $LANG_configselects;') !== false,
        'Radio language files must declare Geeklog configuration language arrays as globals: ' . $languageName
    );
    radio_contract_require(
        strpos($languageFile, "\$LANG_confignames['radio']") !== false,
        'Radio language file must define LANG_confignames[radio]: ' . $languageName
    );
}

foreach (array(
    'radio_media',
    'radio_programs',
    'radio_program_items',
    'radio_schedule',
    'radio_events',
    'radio_sources',
    'radio_source_sync_log'
) as $table) {
    radio_contract_require(
        strpos($autoinstall, "'" . $table . "'") !== false,
        'Autoinstall/uninstall contract is missing table ' . $table . '.'
    );
}

$id3Support = file_get_contents($root . '/lib/id3.inc.php');
$mediaEditAdmin = file_get_contents($root . '/admin/edit.php');

radio_contract_require(
    strpos($functions, 'function RADIO_libraryMode') !== false
        && strpos($functions, 'function RADIO_sharedMediaEnabled') !== false
        && strpos($functions, 'function RADIO_libraryInfo') !== false
        && strpos($functions, 'function RADIO_syncSharedMediaLibrary') !== false
        && strpos($functions, 'function RADIO_prepareSharedMediaUpdate') !== false
        && strpos($functions, 'function RADIO_writeMediaMetadataToFile') !== false
        && strpos($functions, 'function RADIO_syncMediaMetadataFromFile') !== false
        && strpos($defaults, "'library_mode' => 'local'") !== false
        && strpos($defaults, "'shared_storage_path' => ''") !== false
        && strpos($defaults, "'shared_media_sync_interval' => 300") !== false
        && strpos($mysqlInstall, 'metadata_mtime bigint(20) unsigned') !== false
        && strpos($mysqlInstall, 'shared_hidden tinyint(1) unsigned') !== false
        && strpos($id3Support, 'function RADIO_id3ReadTag') !== false
        && strpos($id3Support, 'function RADIO_id3WriteMetadata') !== false
        && strpos($mediaEditAdmin, "name=\"sync_metadata_from_file\"") !== false
        && strpos($mediaEditAdmin, "name=\"write_metadata_to_file\"") !== false,
    'Radio 0.5.1 shared-media mode must remain opt-in, keep site databases independent and synchronize common MP3 metadata through ID3 tags.'
);

radio_contract_require(
    preg_match('/function\s+RADIO_detectAudioDuration\s*\(/', $functions) === 1,
    'Radio must provide server-side audio duration detection.'
);
radio_contract_require(
    strpos($functions, 'RADIO_detectM4aDuration') !== false
        && strpos($functions, 'RADIO_detectMp3Duration') !== false,
    'Radio duration detection must cover M4A and MP3.'
);
radio_contract_require(
    substr_count($functions, 'RADIO_detectAudioDuration(') >= 3,
    'Radio must use duration detection for new and existing local media.'
);

radio_contract_require(
    strpos($defaults, "'on_demand_enabled' => 1") !== false,
    'Radio must provide an enabled-by-default on_demand_enabled configuration.'
);
radio_contract_require(
    strpos($publicIndex, 'radio-home-audio') !== false
        && strpos($publicIndex, 'radio-home-wave') !== false,
    'Radio public index must expose the native home live player and waveform.'
);
radio_contract_require(
    strpos($publicIndex, '<progress') === false
        && strpos($publicIndex, 'radio-on-air-progress') === false,
    'Radio public home must use a single native audio timeline.'
);
radio_contract_require(
    strpos($publicJs, "liveSource === 'semi-live'") !== false
        && strpos($publicJs, 'syncTick % 5 === 0') !== false
        && strpos($publicJs, '}, 3000);') !== false
        && strpos($publicJs, 'data.current_media') !== false,
    'Radio public index player must synchronize every 3 seconds during semi-live and retain the normal 15-second cadence otherwise.'
);
radio_contract_require(
    strpos($publicJs, 'AudioContext') !== false
        && strpos($publicJs, 'createAnalyser') !== false
        && strpos($publicJs, 'getByteTimeDomainData') !== false
        && strpos($publicJs, 'visualGain') !== false,
    'Radio public waveform must use normalized Web Audio time-domain analysis where available.'
);
radio_contract_require(
    strpos($publicIndex, 'radio-home-wave') !== false,
    'Radio waveform canvas must be present on the public home player.'
);
radio_contract_require(
    strpos($nowEndpoint, "'source_kind'") !== false,
    'Radio now endpoint must expose source_kind for safe waveform handling.'
);
radio_contract_require(
    strpos($functions, 'RADIO_publicStylesheetLink') !== false
        && strpos($functions, 'RADIO_publicScriptTag') !== false
        && strpos($functions, 'RADIO_adminScriptTag') !== false
        && strpos($functions, 'RADIO_assetVersion') !== false,
    'Radio must load versioned public CSS/JS and admin JavaScript assets.'
);
radio_contract_require(
    strpos($functions, 'radio.css') !== false
        && strpos($functions, 'radio.js') !== false
        && strpos($functions, 'radio-admin.js') !== false,
    'Radio versioned asset callbacks must reference the packaged asset files.'
);

radio_contract_require(
    strpos($functions, 'function RADIO_isEnabled()') !== false
        && strpos($functions, 'function RADIO_publicAccessAllowed()') !== false
        && strpos($functions, 'function RADIO_requirePublicAccess($renderPublicMessage = false)') !== false
        && strpos($functions, 'http_response_code(410)') !== false
        && strpos($functions, "header('HTTP/1.1 410 Gone')") !== false
        && strpos($publicIndex, 'RADIO_requirePublicAccess(true);') !== false
        && strpos($publicProgram, 'RADIO_requirePublicAccess(true);') !== false
        && strpos($publicReplay, 'RADIO_requirePublicAccess(true);') !== false
        && strpos($publicSchedule, 'RADIO_requirePublicAccess(true);') !== false,
    'Disabled public Radio must return HTTP 410 for public HTML pages while allowing Radio administrative users through.'
);

radio_contract_require(
    strpos($functions, 'function plugin_configchange_radio($group, $changes = array())') !== false
        && strpos($functions, "in_array('enabled', \$changes, true)") !== false
        && strpos($functions, 'function RADIO_queuePublicAvailabilityChange($enabled)') !== false
        && strpos($functions, 'function RADIO_processPublicAvailabilityQueue($limit = 5)') !== false
        && strpos($functions, 'function plugin_runScheduledTask_radio()') !== false
        && strpos($functions, "PLG_itemSaved(RADIO_externalId('media'") !== false
        && strpos($functions, "PLG_itemSaved(RADIO_externalId('program'") !== false
        && strpos($functions, 'RADIO_queuePublicAvailabilityChange(RADIO_isEnabled());') !== false
        && strpos($functions, 'if (!RADIO_isEnabled())') !== false,
    'Public Radio availability changes must queue bounded lifecycle events outside configuration saves and withdraw disabled Radio items from the sitemap.'
);

radio_contract_require(
    strpos($publicPlayerPage, 'RADIO_requirePublicAccess();') !== false
        && strpos($publicMediaEndpoint, 'RADIO_requirePublicAccess();') !== false
        && strpos($nowEndpoint, 'RADIO_requirePublicAccess();') !== false,
    'Disabled Radio must block public player, media and live API endpoints.'
);

radio_contract_require(
    strpos($functions, 'if ($isAdmin || $isRadioConfig)') !== false
        && strpos($functions, 'return RADIO_adminStylesheetLink();') !== false
        && strpos($functions, "strpos(\$path, '/admin/plugins/radio/') !== false") !== false
        && strpos($functions, 'RADIO_adminScriptTag()') !== false,
    'Radio admin CSS and JavaScript must remain available on Radio administration pages while public Radio is disabled.'
);
radio_contract_require(
    strpos($publicJs, 'function initHomePlayer') !== false
        && strpos($adminJs, 'radio-upload-file') !== false
        && strlen($publicCss) > 100,
    'Radio CSS/JS asset files must contain the expected public/admin behavior.'
);

radio_contract_require(
    preg_match('/function\\s+plugin_getmenuitems_radio\\s*\\(/', $functions) === 1,
    'Radio must expose a public Geeklog plugin-menu callback.'
);
radio_contract_require(
    preg_match('/function\\s+plugin_getBlocks_radio\\s*\\(/', $functions) === 1
        && preg_match('/function\\s+plugin_getBlocksConfig_radio\\s*\\(/', $functions) === 1,
    'Radio must expose Geeklog dynamic block callbacks.'
);
radio_contract_require(
    strpos($functions, 'RADIO_renderBlock') !== false
        && strpos($functions, 'radio_now_playing') !== false
        && strpos($functions, 'RADIO_blockStylesheetLink') !== false,
    'Radio dynamic now-playing block and versioned block stylesheet must be present.'
);
radio_contract_require(
    strpos($defaults, "'block_enabled' => 0") !== false
        && strpos($defaults, "'block_isleft' => 0") !== false
        && strpos($defaults, "'block_order' => 50") !== false,
    'Radio dynamic block configuration defaults must be present.'
);
radio_contract_require(
    file_exists($root . '/public_html/radio-block.css'),
    'Radio dynamic block stylesheet must be packaged.'
);
if (!empty($errors)) {
    fwrite(STDERR, "Radio Plugin API contract check failed:\n");
    foreach ($errors as $error) {
        fwrite(STDERR, " - " . $error . "\n");
    }
    exit(1);
}

echo "Radio Plugin API contract check passed.\n";

radio_contract_require(
    strpos(file_get_contents($root . '/public_html/schedule.php'), 'radio-schedule-grid') !== false
        && strpos(file_get_contents($root . '/public_html/schedule.php'), 'radio-day-card') !== false,
    'Radio public schedule must use the responsive card layout.'
);
radio_contract_require(
    strpos($publicCss, '.radio-week-nav') !== false
        && strpos($publicCss, '.radio-schedule-grid') !== false
        && strpos($publicCss, '.radio-day-card--today') !== false,
    'Radio public stylesheet must include modern schedule navigation and day-card styles.'
);


radio_contract_require(
    strpos($studioJs, 'function updateDjValue') !== false
        && strpos($studioJs, "padButton.disabled = !mediaId || !url") !== false
        && strpos($studioJs, "padLabel.textContent = mediaId && label ? label : 'PAD ' + pad") !== false,
    'Radio Studio touch controls must expose immediate value feedback and large pad labels tied to the assigned jingle.'
);

radio_contract_require(
    strpos($studioPage, 'data-radio-studio-focus') !== false
        && strpos($studioPage, 'data-radio-djfx-scope') !== false
        && strpos($studioPage, 'data-radio-djmode') === false
        && strpos($studioPage, 'data-radio-djmode-fx') === false,
    'Radio Studio must use one complete interface with an optional dark focus theme and no duplicate DJ control tree.'
);

radio_contract_require(
    strpos($studioJs, 'function setStudioFocus') !== false
        && strpos($studioJs, "document.body.classList.toggle('radio-studio-focus-active'") !== false
        && strpos($studioJs, "studio.classList.toggle('radio-studio--focus'") !== false
        && strpos($studioJs, 'syncDjModeControl') === false
        && strpos($studioJs, 'refreshDjModePads') === false,
    'Radio Studio focus mode must only change presentation and must not synchronize duplicate controls.'
);

radio_contract_require(
    strpos($publicPlayer, 'context.createAnalyser()') !== false
        && strpos($publicPlayer, 'function drawScope()') !== false
        && strpos($publicPlayer, "root.querySelector('[data-radio-djfx-scope]')") !== false,
    'Radio Studio DJ mode oscilloscope must be driven by the existing Web Audio graph.'
);


radio_contract_require(
    strpos($programsPage, 'radio-programs-layout') !== false
        && strpos($programsPage, 'radio-programs-editor') !== false
        && strpos($programsPage, 'radio-programs-form') !== false,
    'Radio programme administration must use responsive layout classes instead of a fixed inline grid.'
);

radio_contract_require(
    strpos($studioJs, "dispatchDjFx('activate', 1)") !== false
        && strpos($publicPlayer, "audio.addEventListener('play', function ()") !== false
        && strpos($publicPlayer, "context.resume().catch(function () {})") !== false,
    'Radio Studio must activate its shared analyser from playback or focus without a second player.'
);


radio_contract_require(
    strpos($studioJs, 'function interceptStudioInlineForms') !== false
        && strpos($studioJs, "form.classList.contains('radio-studio__inline-form')") !== false
        && strpos($studioJs, "event.preventDefault()") !== false
        && strpos($studioJs, "mutateItem(action, itemId)") !== false
        && strpos($studioJs, "addMedia(mediaId, position)") !== false,
    'Radio Studio must intercept server-rendered playlist forms and keep Play next, add, move and remove actions AJAX-only without a page reload.'
);


radio_contract_require(
    strpos($studioJs, "line.className = 'radio-studio__buffer-line';") !== false
        && strpos($studioJs, 'bufferStatus.appendChild(line);') !== false
        && strpos($studioJs, "parts.join(' | ')") === false,
    'Radio Studio buffer status must render Current, Next and Reserve on separate lines.'
);

radio_contract_require(
    strpos($studioJs, 'function updateDjValue(range)') !== false
        && strpos($studioJs, 'if (!range || !djFx)') !== false
        && strpos($studioJs, 'function syncDjModeControl') === false,
    'Radio Studio must keep one DJ value helper and one set of FX controls.'
);


radio_contract_require(
    strpos($defaults, "'media_delivery_mode' => 'auto'") !== false
        && strpos($defaults, "'x_accel_internal_prefix' => ''") !== false
        && strpos($functions, 'function RADIO_mediaDeliveryMode') !== false
        && strpos($functions, 'function RADIO_sendMediaViaWebServer') !== false
        && strpos($functions, "header('X-Sendfile: ' . $path)") !== false
        && strpos($functions, "header('X-Accel-Redirect: ' . $internal)") !== false
        && strpos($functions, '$playbackRangeChunk = 2 * 1024 * 1024;') !== false
        && strpos($functions, '$end = min($end, $start + $playbackRangeChunk - 1);') !== false
        && strpos($functions, '@session_write_close();') !== false
        && strpos($functions, "@ini_set('zlib.output_compression', '0');") !== false
        && strpos($functions, 'while (ob_get_level() > 0)') !== false
        && strpos($functions, "header('X-Accel-Buffering: no')") !== false
        && strpos($functions, 'min(262144, $remaining)') !== false,
    'Radio local media delivery must offload when possible and keep PHP fallback ranges HTTP/2-safe.'
);

radio_contract_require(
    strpos($functions, 'RADIO_purgeOldStats();') === false
        && strpos(file_get_contents($root . '/admin/stats.php'), 'RADIO_purgeOldStats();') !== false,
    'Radio statistics retention cleanup must not run on every listener event.'
);


radio_contract_require(
    strpos($publicPlayer, "root.closest('[data-radio-studio]')") !== false
        && strpos($publicPlayer, "document.querySelector('[data-radio-djfx-scope]')") !== false,
    'Radio DJ oscilloscope must find its canvas outside the replay player subtree.'
);


radio_contract_require(
    strpos($adminCss, '.radio-program-preview.radio-studio--focus .radio-replay__player') !== false
        && strpos($adminCss, 'background:#11161e!important') !== false,
    'Radio Studio dark focus mode must restyle the replay player surface instead of inheriting the light Eclipse surface.'
);


radio_contract_require(
    strpos($studioJs, "dispatchDjFx('sample-assign'") !== false
        && strpos($studioJs, "dispatchDjFx('sample-play', {pad: pad})") !== false,
    'Radio Studio pads must assign their selected jingle to the Web Audio sample engine before playback.'
);


radio_contract_require(
    strpos($studioPage, 'data-radio-djfx-push="low"') !== false
        && strpos($studioPage, 'data-radio-djfx-push="mid"') !== false
        && strpos($studioPage, 'data-radio-djfx-push="high"') !== false
        && strpos($studioPage, 'data-radio-djfx-push="filter"') !== false
        && strpos($studioJs, 'var djPushTimers = {};') !== false
        && strpos($studioJs, '}, 220);') !== false,
    'Radio Studio must expose momentary +/-10 DJ FX push controls that automatically return to zero.'
);

radio_contract_require(
    strpos($publicPlayer, 'sample.gain = context.createGain();') !== false
        && strpos($publicPlayer, 'Math.pow(10, 5 / 20)') !== false
        && strpos($publicPlayer, 'sample.compressor = context.createDynamicsCompressor();') !== false
        && strpos($publicPlayer, 'sample.compressor.threshold.value = -6;') !== false
        && strpos($publicPlayer, 'programmeGain = context.createGain();') !== false
        && strpos($publicPlayer, 'Math.pow(10, -4 / 20)') !== false
        && strpos($publicPlayer, 'linearRampToValueAtTime(1, releaseTime + 0.28)') !== false
        && strpos($publicPlayer, 'sample.compressor.connect(master);') !== false,
    'Radio Studio jingle pads must stay clearly above programme audio without clipping, using moderate gain, ducking and limiting.'
);


radio_contract_require(
    strpos($studioPage, 'data-radio-studio-action="move_up"') !== false
        && strpos($studioPage, 'data-radio-studio-action="move_down"') !== false
        && strpos($studioPage, 'data-radio-studio-action="remove"') !== false
        && strpos($studioPage, 'data-radio-studio-position="next"') !== false
        && strpos($studioPage, 'data-radio-studio-position="end"') !== false
        && strpos($studioJs, 'function bindStudioActionDelegation') !== false
        && strpos($studioJs, "button.hasAttribute('data-radio-studio-action')") !== false
        && strpos($studioJs, "button.hasAttribute('data-radio-studio-add')") !== false,
    'Radio Studio queue and media actions must use one delegated click contract for server-rendered and dynamic controls.'
);


radio_contract_require(
    strpos($studioPage, 'data-radio-djfx="pan"') !== false
        && strpos($studioPage, 'radio-studio__djfx-pan-center') !== false
        && strpos($studioPage, 'data-radio-djfx-spring="pan"') === false
        && strpos($publicPlayer, 'context.createStereoPanner') !== false
        && strpos($publicPlayer, "control === 'pan'") !== false,
    'Radio Studio must provide a persistent true stereo pan control with a visible centered detent.'
);


radio_contract_require(
    strpos($uploadAdmin, '$batchMediaType = isset($_POST[\'media_type\'])') !== false
        && strpos($uploadAdmin, "'jingle'") !== false
        && strpos($uploadAdmin, '$metadata[\'media_type\'] = $batchMediaType;') !== false
        && strpos($functions, "'music', 'podcast', 'interview', 'show', 'chronicle', 'jingle', 'announcement', 'promo'") !== false,
    'Radio batch uploader must preserve a selected Jingle media type for every uploaded file.'
);


radio_contract_require(
    strpos($studioJs, 'var mutationInFlight = 0;') !== false
        && strpos($studioJs, 'var stateRevision = 0;') !== false
        && strpos($studioJs, 'if (mutationInFlight > 0)') !== false
        && strpos($studioJs, 'requestRevision !== stateRevision') !== false,
    'Radio Studio polling must ignore stale state responses while playlist mutations are in flight.'
);


radio_contract_require(
    strpos($publicPlayer, 'current_remaining: currentRemaining') !== false
        && strpos($publicPlayer, 'parseFloat(items[index].transition_overlap || 0)') !== false
        && strpos($publicPlayer, 'if (overlap <= 0)') !== false
        && strpos($studioJs, "data-buffer-current-label") !== false
        && strpos($studioJs, 'compactTime(currentRemaining)') !== false,
    'Radio Studio must show current-track remaining time and preserve fractional transition overlaps.'
);


radio_contract_require(
    strpos($publicPlayer, 'var minHz = 40;') !== false
        && strpos($publicPlayer, 'var maxHz = Math.min(18000, nyquist);') !== false
        && strpos($publicPlayer, 'Math.exp(logMin + (logMax - logMin)') !== false
        && strpos($publicPlayer, 'peak = Math.max(peak, scopeFreq[fi]);') !== false,
    'Radio Studio spectrum must use a logarithmic audible-frequency scale so the full histogram width remains useful.'
);


radio_contract_require(
    strpos($adminCss, '.radio-studio__djfx-pad-trigger{') !== false
        && strpos($adminCss, 'max-width:100%') !== false
        && strpos($adminCss, '.radio-studio__djfx-pad-trigger strong{') !== false
        && strpos($adminCss, 'text-overflow:ellipsis') !== false,
    'Radio Studio jingle pad labels must stay contained inside their pad cards.'
);


radio_contract_require(
    strpos($studioPage, 'radio-studio__djfx-filter-control') !== false
        && strpos($studioPage, 'radio-studio__djfx-pan-inline') !== false
        && strpos($studioPage, 'radio-studio__djfx-actions') !== false
        && strpos($studioPage, 'data-radio-djfx="headroom"') !== false
        && strpos($studioPage, 'min="-10" max="10"') !== false
        && strpos($studioJs, "getAttribute('data-radio-djfx') === 'headroom'") !== false
        && strpos($publicPlayer, 'headroomGain = context.createGain();') !== false
        && strpos($publicPlayer, 'Math.max(-10, Math.min(10') !== false
        && strpos($publicPlayer, 'Math.pow(10, headroomDb / 20)') !== false
        && strpos($publicPlayer, 'masterLimiter = context.createDynamicsCompressor();') !== false
        && strpos($publicPlayer, 'masterLimiter.threshold.value = -1;') !== false,
    'Radio Studio must group stereo pan under FILTER, stack Echo/Reset, and provide independent -10..+10 dB headroom with master limiting.'
);

$installDefaults = file_get_contents($root . '/install_defaults.php');
$updates = file_get_contents($root . '/install_updates.php');
$youtubeAdmin = file_get_contents($root . '/admin/youtube.php');
$youtubeWorker = file_get_contents($root . '/bin/youtube-live.php');
$adminNav = file_get_contents($root . '/admin/admin-ui.inc.php');
$adminNavTemplate = file_get_contents($root . '/templates/admin/navigation.thtml');
$adminNavigationTemplate = $adminNavTemplate;
$adminConfigurationTemplate = file_get_contents($root . '/templates/admin/configuration-button.thtml');
$adminCssFile = file_get_contents($root . '/admin/radio-admin.css');

radio_contract_require(
    strpos($youtubeAdmin, '$config = RADIO_youtubeConfig();') === false
        && strpos($youtubeAdmin, '$youtubeConfig = RADIO_youtubeConfig();') !== false,
    'Radio YouTube administration must not overwrite Geeklog\'s global $config object with plugin runtime configuration.'
);

radio_contract_require(
    strpos($youtubeAdmin, "\$youtubeLibrary = \$_CONF['path'] . 'plugins/radio/lib/youtube.inc.php';") !== false
        && strpos($youtubeAdmin, 'is_file($youtubeLibrary) && is_readable($youtubeLibrary)') !== false
        && strpos($youtubeAdmin, "function_exists('RADIO_youtubeConfig')") !== false
        && strpos($youtubeAdmin, 'youtube_module_unavailable') !== false
        && strpos($youtubeAdmin, 'RADIO_adminRenderPage(') !== false,
    'Radio YouTube administration must fail with a normal Geeklog page when the optional server-side module is missing or incomplete.'
);

radio_contract_require(
    strpos($youtubeAdmin, "SEC_hasRights('radio.admin')") !== false
        && strpos($youtubeAdmin, 'SEC_checkToken()') !== false
        && strpos($youtubeAdmin, 'RADIO_ensureConfig();') === false
        && strpos($youtubeAdmin, "classes/config.class.php") === false
        && strpos($youtubeAdmin, 'name="stream_key"') === false
        && strpos($youtubeAdmin, 'youtube_stream_key_configured') !== false
        && strpos($youtubeAdmin, 'RADIO_youtubeSetManualRequest') !== false,
    'Radio YouTube Live administration must use the already-loaded Radio configuration, require admin rights and CSRF protection, and never render the saved stream key.'
);

radio_contract_require(
    strpos($updates, "'0.6.0' => array(") !== false
        && strpos($updates, "'next' => '0.6.1'") !== false
        && strpos($updates, "'callback' => 'radio_update_0_6_0_to_0_6_1'") !== false
        && strpos($updates, 'function radio_update_0_6_0_to_0_6_1()') !== false,
    'Radio 0.6.0 installations must have an explicit upgrade path to 0.6.1 so configuration reconciliation adds the YouTube settings.'
);

radio_contract_require(
    strpos($installDefaults, "'youtube_enabled' => 0") !== false
        && strpos($installDefaults, "'youtube_mode' => 'scheduled'") !== false
        && strpos($installDefaults, "'youtube_rtmp_url' => 'rtmps://a.rtmps.youtube.com/live2'") !== false
        && strpos($installDefaults, "'youtube_stream_key' => ''") !== false
        && strpos($installDefaults, "'youtube_video_size' => '1280x720'") !== false
        && strpos($installDefaults, "'youtube_audio_bitrate' => '128k'") !== false
        && strpos($youtubeLib, "\$_RADIO_CONF['youtube_enabled']") !== false
        && strpos($youtubeLib, "\$_RADIO_CONF['youtube_stream_key']") !== false,
    'YouTube Live base settings must live in the normal Radio configuration and be consumed by the server-side worker.'
);

radio_contract_require(
    strpos($youtubeLib, 'function RADIO_youtubeTarget') !== false
        && strpos($youtubeLib, 'function RADIO_youtubeFfmpegCommand') !== false
        && strpos($youtubeLib, "'rtmps://a.rtmps.youtube.com/live2'") !== false
        && strpos($youtubeLib, "RADIO_sourceKind(\$item) !== 'local'") !== false
        && strpos($youtubeLib, 'youtube-live-state.json') !== false,
    'Radio YouTube Live must keep server-side scheduling, FFmpeg generation and private runtime state separate from browser playback.'
);

radio_contract_require(
    strpos($youtubeLib, "\$renderVisualizer = \$template === 'visualizer'") !== false
        && strpos($youtubeLib, "\$template === 'minimal' ? false : \$showVisualizer") !== false
        && strpos($youtubeLib, "'-r', '25'") !== false
        && strpos($youtubeLib, "'-sc_threshold', '0'") !== false
        && strpos($youtubeLib, 'brightness=-0.28') === false
        && strpos($youtubeLib, 'overlay=0:0:eof_action=repeat[background]') !== false,
    'YouTube visual templates must keep Minimal lightweight, force Visualizer animation, share a stable 25 fps encoder clock, and preserve Full Background artwork luminance.'
);

radio_contract_require(
    strpos($youtubeLib, "'visual_style' => 'modern_white'") !== false
        && strpos($youtubeLib, "array('modern_white','studio_green')") !== false
        && strpos($youtubeLib, "function RADIO_youtubeVisualPalette") !== false
        && strpos($youtubeLib, "'primary' => '0x00D060'") !== false
        && strpos($youtubeLib, "'background' => '0x030805'") !== false
        && strpos($youtubeLib, "'style' => isset(\$config['visual_style'])") !== false
        && strpos($youtubeAdmin, 'name="visual_style"') !== false
        && strpos($youtubeAdmin, "youtube_style_modern_white") !== false
        && strpos($youtubeAdmin, "youtube_style_studio_green") !== false,
    'YouTube visuals must provide modern white and Studio green themes, include the selected style in the restart signature, and use the Studio green accent on a near-black background.'
);

radio_contract_require(
    strpos($youtubeLib, '"Style: Program,DejaVu Sans,17,"') !== false
        && strpos($youtubeLib, '"Style: Track,DejaVu Sans,15,"') !== false
        && strpos($youtubeLib, "RADIO_youtubeAssWrappedText(\$program, 52, 2)") !== false
        && strpos($youtubeLib, "RADIO_youtubeAssWrappedText(\$title, 84, 2)") !== false
        && strpos($youtubeLib, "\$waveX = '(W-w)/2'") !== false
        && strpos($youtubeLib, "\$lowerThirdMargin = max(60, (int) floor((\$width - \$waveWidth) / 2))") !== false
        && strpos($youtubeLib, "\$bottomSafeMargin = max(42, (int) floor(\$height * 0.06))") !== false
        && strpos($youtubeLib, "\$waveBottom = max(100, (int) floor(\$videoHeight * 0.14))") !== false
        && strpos($youtubeLib, ":fontsize=17:x=(w-760)/2:y=h-72") !== false
        && strpos($youtubeLib, ":fontsize=15:x=(w-760)/2:y=h-50") !== false,
    'YouTube track titles must stay discreet: smaller typography, at most two lines, and subdued secondary colour.'
);

radio_contract_require(
    strpos($youtubeLib, "\$videoPreset = 'veryfast'") !== false
        && strpos($youtubeLib, "\$videoPreset = 'superfast'") !== false
        && strpos($youtubeLib, "'-preset', \$videoPreset") !== false
        && strpos($youtubeLib, "'-thread_queue_size', '64'") !== false
        && strpos($youtubeLib, 'flags=fast_bilinear') !== false
        && strpos($youtubeLib, "'-stats_period', '15'") !== false
        && strpos($youtubeLib, 'rc-lookahead=0:sync-lookahead=0') !== false,
    'Full Background must reserve CPU headroom, throttle its static artwork input, and emit periodic FFmpeg realtime stats for ingest diagnostics.'
);

radio_contract_require(
    strpos($youtubeLib, "'primary' => '0xFFFFFF'") !== false
        && strpos($youtubeLib, "'secondary' => '0xDDE3E8'") !== false
        && strpos($youtubeLib, "'primary' => '0x00D060'") !== false
        && strpos($youtubeLib, "'secondary' => '0x00A84C'") !== false
        && strpos($youtubeLib, '"Style: Track,DejaVu Sans,16," . $palette[\'ass_primary\']') !== false,
    'YouTube white and green styles must stay luminous on black; track hierarchy comes from size and weight rather than dim text colour.'
);

radio_contract_require(
    strpos($youtubeWorker, 'RADIO_studioYoutubeActive') !== false
        && strpos($youtubeWorker, 'Studio Live owns the ingest') !== false,
    'Automatic YouTube worker must stand down while Studio Live owns the stream key.'
);

radio_contract_require(
    strpos($youtubeLib, "'waveform_style' => 'line'") !== false
        && strpos($youtubeLib, "array('line','cline','p2p')") !== false
        && strpos($youtubeLib, "'waveform_style' => isset(\$config['waveform_style'])") !== false
        && strpos($youtubeLib, "':mode=' . \$waveformStyle") !== false
        && strpos($youtubeAdmin, 'name="waveform_style"') !== false
        && strpos($youtubeAdmin, "youtube_waveform_cline") !== false
        && strpos($youtubeAdmin, "youtube_waveform_p2p") !== false,
    'YouTube visualizer must persist Line, Centered line and Point-to-point waveform modes and include the choice in the visual restart signature.'
);

radio_contract_require(
    strpos($youtubeLib, 'function RADIO_youtubeFfmpegMetrics') !== false
        && strpos($youtubeLib, "'-stats_period', '15'") !== false
        && strpos($youtubeLib, "preg_match('/fps=") !== false
        && strpos($youtubeLib, "preg_match('/bitrate=") !== false
        && strpos($youtubeLib, "preg_match('/speed=") !== false
        && strpos($youtubeLib, "\$result['age'] > 45") !== false
        && strpos($youtubeAdmin, "youtube_encoding_diagnostics") !== false
        && strpos($youtubeAdmin, "youtube_metric_fps") !== false
        && strpos($youtubeAdmin, "youtube_metric_bitrate") !== false
        && strpos($youtubeAdmin, "youtube_metric_speed") !== false,
    'YouTube administration must expose fresh FFmpeg FPS, video bitrate and realtime encoding speed diagnostics.'
);

radio_contract_require(
    strpos($youtubeWorker, "PHP_SAPI !== 'cli'") !== false
        && strpos($youtubeWorker, 'GEEKLOG_ROOT') !== false
        && strpos($youtubeWorker, 'RADIO_youtubeTarget(time())') !== false
        && strpos($youtubeWorker, 'nohup ') !== false
        && strpos($youtubeWorker, 'RADIO_youtubeStopPid') !== false,
    'Radio YouTube Live worker must be CLI-only and reconcile FFmpeg with the configured target.'
);

radio_contract_require(
    strpos($functions, 'function plugin_getadminoption_radio()') !== false
        && strpos($functions, 'function plugin_cclabel_radio()') !== false
        && strpos($functions, 'function plugin_geticon_radio()') !== false
        && strpos($functions, "return rtrim(\$_CONF['site_url'], '/') . '/radio/images/plugin.svg';") !== false
        && strpos($functions, "if (!SEC_hasRights('radio.admin')) {\n        return array();") !== false,
    'Radio administration must expose Geeklog native admin-menu and Command & Control discovery hooks without relying on a theme.'
);

radio_contract_require(
    strpos($adminNavigationTemplate, 'class="plugin-admin-nav radio-admin__nav"') !== false
        && strpos($adminNavigationTemplate, 'class="plugin-admin-nav__primary radio-admin__nav-primary"') !== false
        && strpos($adminNavigationTemplate, '{nav_configuration}') !== false
        && strpos($adminConfigurationTemplate, 'class="plugin-admin-nav__form radio-admin__config-form"') !== false
        && strpos($adminConfigurationTemplate, 'name="conf_group" value="radio"') !== false
        && strpos($adminConfigurationTemplate, 'plugin-admin-nav__item') !== false
        && strpos($adminNav, 'aria-current="page"') !== false
        && strpos($adminCssFile, '.plugin-admin-nav__primary') !== false
        && strpos($adminCssFile, '.plugin-admin-nav__item') !== false,
    'Radio persistent administration navigation must follow the Memorandum plugin-admin-nav contract and remain theme-neutral.'
);

radio_contract_require(
    strpos($adminNav, "'nav_youtube'") !== false
        && strpos($adminNavTemplate, '{nav_youtube}') !== false,
    'Radio administration must expose the YouTube Live screen through the shared navigation.'
);

