<?php
require_once '../lib-common.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$download = !empty($_GET['download']);
$startSeconds = isset($_GET['start']) ? max(0, (int) $_GET['start']) : 0;
$row = RADIO_getMedia($id, false);

if ($row !== false) {
    $published = isset($row['status']) && $row['status'] === 'published';
    if ($published) {
        if (!RADIO_hasReadAccess($row)) {
            $row = false;
        }
    } elseif (!RADIO_hasEditAccess($row)) {
        $row = false;
    }
}

if ($row === false) {
    header('HTTP/1.1 404 Not Found');
    exit;
}

if ($download && !RADIO_downloadAllowed($row)) {
    header('HTTP/1.1 403 Forbidden');
    exit;
}
if ($download) {
    RADIO_recordStatEvent($id, 0, 'download', 'download', 0);
}

if (!RADIO_sendMedia($row, $download, $startSeconds)) {
    header($download ? 'HTTP/1.1 403 Forbidden' : 'HTTP/1.1 404 Not Found');
    exit;
}
