(function () {
    'use strict';

    function q(selector, root) {
        return (root || document).querySelector(selector);
    }

    function postEvent(endpoint, mediaId, programId, eventType, seconds) {
        if (!endpoint || !mediaId) {
            return;
        }
        var body = new URLSearchParams();
        body.set('media_id', mediaId);
        body.set('program_id', programId || 0);
        body.set('event_type', eventType);
        body.set('source', 'persistent');
        body.set('seconds', Math.max(0, Math.round(seconds || 0)));

        if (navigator.sendBeacon) {
            navigator.sendBeacon(endpoint, body);
            return;
        }
        fetch(endpoint, {
            method: 'POST',
            body: body,
            credentials: 'same-origin',
            keepalive: true
        }).catch(function () {});
    }

    function waveform(canvas, audio) {
        var context = null;
        var analyser = null;
        var source = null;
        var data = null;
        var fallback = false;
        var external = false;

        function setup() {
            if (context || fallback || external) {
                return;
            }
            try {
                var AudioContext = window.AudioContext || window.webkitAudioContext;
                if (!AudioContext) {
                    fallback = true;
                    return;
                }
                context = new AudioContext();
                source = context.createMediaElementSource(audio);
                analyser = context.createAnalyser();
                analyser.fftSize = 128;
                analyser.smoothingTimeConstant = 0.72;
                data = new Uint8Array(analyser.fftSize);
                source.connect(analyser);
                analyser.connect(context.destination);
            } catch (error) {
                fallback = true;
            }
        }

        function drawFallback(ctx, width, height) {
            var points = 36;
            var t = Date.now() / 180;
            ctx.beginPath();
            for (var i = 0; i < points; i++) {
                var x = i * width / (points - 1);
                var envelope = Math.sin(Math.PI * i / (points - 1));
                var y = height / 2
                    + Math.sin(t + i * .58) * envelope * height * .23
                    + Math.sin(t * .5 + i * .2) * height * .045;
                if (i === 0) {
                    ctx.moveTo(x, y);
                } else {
                    ctx.lineTo(x, y);
                }
            }
            ctx.stroke();
        }

        function draw() {
            var ctx = canvas.getContext('2d');
            if (!ctx) {
                return;
            }
            var width = canvas.width;
            var height = canvas.height;
            ctx.clearRect(0, 0, width, height);
            ctx.strokeStyle = window.getComputedStyle(canvas).color || '#000';
            ctx.lineWidth = 1.5;

            if (audio.paused) {
                ctx.beginPath();
                ctx.moveTo(0, height / 2);
                ctx.lineTo(width, height / 2);
                ctx.stroke();
            } else if (analyser && data && !external) {
                analyser.getByteTimeDomainData(data);
                ctx.beginPath();
                for (var i = 0; i < data.length; i++) {
                    var x = i * width / (data.length - 1);
                    var y = (data[i] / 255) * height;
                    if (i === 0) {
                        ctx.moveTo(x, y);
                    } else {
                        ctx.lineTo(x, y);
                    }
                }
                ctx.stroke();
            } else {
                drawFallback(ctx, width, height);
            }
            window.requestAnimationFrame(draw);
        }

        return {
            setExternal: function (value) {
                external = !!value;
                if (external) {
                    fallback = true;
                }
            },
            start: function () {
                setup();
                if (context && context.state === 'suspended') {
                    context.resume().catch(function () {});
                }
            },
            draw: draw
        };
    }

    function createTransitionManager(audio, hooks) {
        var standby = new Audio();
        var reserve = new Audio();
        standby.preload = 'auto';
        reserve.preload = 'auto';

        var mode = 'hard';
        var seconds = 0;
        var slotDuration = 0;
        var currentDuration = 0;
        var nextMedia = null;
        var nextNextMedia = null;
        var preparedUrl = '';
        var reserveUrl = '';
        var mixing = false;
        var fadeFrame = 0;
        var baseVolume = 1;

        function bufferedAhead(element) {
            if (!element || !element.buffered || element.buffered.length < 1) {
                return 0;
            }

            var position = element.currentTime || 0;
            var best = 0;
            try {
                for (var i = 0; i < element.buffered.length; i++) {
                    var start = element.buffered.start(i);
                    var end = element.buffered.end(i);
                    if (position >= start && position <= end) {
                        best = Math.max(best, end - position);
                    } else if (position === 0 && start <= 0.25) {
                        best = Math.max(best, end);
                    }
                }
            } catch (error) {}
            return Math.max(0, best);
        }

        function bufferTarget(item, minimum, maximum) {
            var duration = item ? (parseInt(item.duration || 0, 10) || 0) : 0;
            var target = duration > 0 ? Math.max(minimum, duration * 0.12) : minimum;
            return Math.min(maximum, target);
        }

        function reportBuffer() {
            if (!hooks || typeof hooks.bufferStatus !== 'function') {
                return;
            }
            hooks.bufferStatus({
                next_buffered: bufferedAhead(standby),
                next_ready: standby.readyState >= 3,
                reserve_ready: reserveUrl !== '' && (reserve.readyState >= 2 || bufferedAhead(reserve) > 0)
            });
        }

        function clearElement(element) {
            element.pause();
            element.removeAttribute('src');
            element.load();
        }

        function clearStandby() {
            clearElement(standby);
            preparedUrl = '';
        }

        function clearReserve() {
            clearElement(reserve);
            reserveUrl = '';
        }

        function maybePrefetchReserve() {
            reportBuffer();
            if (!nextNextMedia || !nextNextMedia.stream_url || !nextMedia) {
                clearReserve();
                return;
            }

            var target = bufferTarget(nextMedia, 3, 12);
            if (standby.readyState < 3 && bufferedAhead(standby) < target) {
                return;
            }

            if (reserveUrl !== nextNextMedia.stream_url) {
                clearReserve();
                reserveUrl = nextNextMedia.stream_url;
                reserve.src = reserveUrl;
                reserve.preload = 'auto';
                reserve.load();
            }
            reportBuffer();
        }

        standby.addEventListener('progress', maybePrefetchReserve);
        standby.addEventListener('canplay', maybePrefetchReserve);
        reserve.addEventListener('progress', reportBuffer);

        function prepare(data) {
            mode = data && data.transition_mode ? data.transition_mode : 'hard';
            seconds = data ? (parseInt(data.transition_seconds || 0, 10) || 0) : 0;
            slotDuration = data && data.current_media
                ? (parseInt(data.current_media.slot_duration || data.current_media.duration || 0, 10) || 0)
                : 0;
            currentDuration = data && data.current_media
                ? (parseInt(data.current_media.duration || 0, 10) || 0)
                : 0;
            nextMedia = data && data.next_media ? data.next_media : null;
            nextNextMedia = data && data.next_next_media ? data.next_next_media : null;

            if (!nextMedia || !nextMedia.stream_url) {
                clearStandby();
                clearReserve();
                reportBuffer();
                return;
            }

            if (preparedUrl !== nextMedia.stream_url) {
                clearStandby();
                preparedUrl = nextMedia.stream_url;
                standby.src = preparedUrl;
                standby.preload = 'auto';
                standby.load();
            }

            if (!nextNextMedia || reserveUrl !== nextNextMedia.stream_url) {
                clearReserve();
            }

            maybePrefetchReserve();
        }

        function handoff(resumeAt) {
            if (!nextMedia) {
                mixing = false;
                audio.volume = baseVolume;
                return;
            }

            var item = nextMedia;
            hooks.activate(item, Math.max(0, resumeAt || 0), function () {
                clearStandby();
                clearReserve();
                audio.volume = baseVolume;
                mixing = false;
            });
        }

        function maybeStart() {
            maybePrefetchReserve();

            if (mode !== 'crossfade' || seconds < 1 || !nextMedia || mixing
                || audio.paused || slotDuration < 1) {
                return;
            }
            if (audio.currentTime + 0.08 < slotDuration) {
                return;
            }

            var required = Math.max(1.25, seconds + 0.75);
            var buffered = bufferedAhead(standby);
            if (standby.readyState < 3 && buffered < required) {
                reportBuffer();
                return;
            }

            if (currentDuration > 0
                && (currentDuration - audio.currentTime) < Math.max(0.35, seconds * 0.35)) {
                return;
            }

            mixing = true;
            baseVolume = Math.max(0, Math.min(1, audio.volume));
            hooks.beforeTransition(nextMedia);

            try {
                standby.currentTime = 0;
            } catch (error) {}
            standby.volume = 0;

            var promise = standby.play();
            if (!promise || typeof promise.then !== 'function') {
                mixing = false;
                audio.volume = baseVolume;
                return;
            }

            promise.then(function () {
                var started = performance.now();

                function fade(now) {
                    if (!mixing) {
                        return;
                    }
                    var progress = Math.min(1, (now - started) / (seconds * 1000));
                    audio.volume = baseVolume * (1 - progress);
                    standby.volume = baseVolume * progress;

                    if (progress < 1) {
                        fadeFrame = window.requestAnimationFrame(fade);
                        return;
                    }

                    handoff(standby.currentTime || seconds);
                }

                fadeFrame = window.requestAnimationFrame(fade);
            }).catch(function () {
                mixing = false;
                audio.volume = baseVolume;
            });
        }

        function handleEnded() {
            if (mixing) {
                return true;
            }

            if ((mode === 'gapless' || mode === 'crossfade') && nextMedia) {
                baseVolume = Math.max(0, Math.min(1, audio.volume));
                hooks.beforeTransition(nextMedia);
                handoff(0);
                return true;
            }
            return false;
        }

        function reset() {
            if (fadeFrame) {
                window.cancelAnimationFrame(fadeFrame);
                fadeFrame = 0;
            }
            mixing = false;
            audio.volume = baseVolume;
            clearStandby();
            clearReserve();
            nextMedia = null;
            nextNextMedia = null;
            reportBuffer();
        }

        return {
            prepare: prepare,
            maybeStart: maybeStart,
            handleEnded: handleEnded,
            reset: reset,
            isMixing: function () { return mixing; },
            bufferState: function () {
                return {
                    next_buffered: bufferedAhead(standby),
                    next_ready: standby.readyState >= 3,
                    reserve_ready: reserveUrl !== '' && (reserve.readyState >= 2 || bufferedAhead(reserve) > 0)
                };
            }
        };
    }

    function init() {
        var root = q('[data-radio-player]');
        if (!root) {
            return;
        }

        var endpoint = root.getAttribute('data-now-endpoint');
        var eventEndpoint = root.getAttribute('data-event-endpoint');
        var emptyLabel = root.getAttribute('data-empty-label') || 'Nothing is on air right now.';
        var listenLabel = root.getAttribute('data-listen-label') || 'Listen';
        var pauseLabel = root.getAttribute('data-pause-label') || 'Pause';
        var autoplayRequested = root.getAttribute('data-autoplay') === '1';
        var audio = q('[data-radio-player-audio]', root);
        var button = q('[data-radio-player-play]', root);
        var title = q('[data-radio-player-title]', root);
        var program = q('[data-radio-player-program]', root);
        var canvas = q('[data-radio-player-scope]', root);
        var wave = waveform(canvas, audio);
        var transitionManager = createTransitionManager(audio, {
            beforeTransition: function () {
                flush();
            },
            activate: function (item, resumeAt, done) {
                mediaId = parseInt(String(item.media_id || '').replace('media:', ''), 10) || 0;
                title.textContent = item.title || '';
                wave.setExternal(item.source_kind && item.source_kind !== 'local');
                audio.src = item.stream_url || '';
                audio.load();

                function startNext() {
                    try {
                        audio.currentTime = Math.max(0, resumeAt || 0);
                    } catch (error) {}
                    wave.start();
                    audio.play().then(function () {
                        if (done) {
                            done();
                        }
                        window.setTimeout(function () {
                            sync(true, false, 0);
                        }, 200);
                    }).catch(function () {
                        if (done) {
                            done();
                        }
                        updateButton();
                    });
                }

                if (audio.readyState >= 1) {
                    startNext();
                } else {
                    audio.addEventListener('loadedmetadata', function once() {
                        audio.removeEventListener('loadedmetadata', once);
                        startNext();
                    });
                }
            }
        });

        var mediaId = 0;
        var programId = 0;
        var wantedPlaying = false;
        var listenStart = 0;
        var endedAt = 0;
        var endedMediaId = 0;
        var endedRetryCount = 0;
        var transitionTimer = 0;
        var transitionProgramId = 0;
        var transitionRetryCount = 0;
        var liveSource = '';
        var syncTick = 0;

        function updateButton() {
            button.textContent = audio.paused ? listenLabel : pauseLabel;
        }

        function flush() {
            if (!listenStart) {
                return;
            }
            postEvent(eventEndpoint, mediaId, programId, 'listen', (Date.now() - listenStart) / 1000);
            listenStart = 0;
        }

        function scheduleTransition(data) {
            if (transitionTimer) {
                window.clearTimeout(transitionTimer);
                transitionTimer = 0;
            }
            transitionProgramId = 0;
            if (!data || (data.source === 'schedule' || data.source === 'semi-live') || !data.upcoming || !data.upcoming.length) {
                return;
            }
            var serverNow = Date.parse(data.generated_at || '');
            var nextStart = Date.parse(data.upcoming[0].start || '');
            if (!isFinite(serverNow) || !isFinite(nextStart) || nextStart <= serverNow) {
                return;
            }
            var delay = nextStart - serverNow;
            if (delay > 86400000) {
                return;
            }
            transitionProgramId = parseInt(String(data.upcoming[0].program_id || '').replace('program:', ''), 10) || 0;
            transitionTimer = window.setTimeout(function () {
                transitionTimer = 0;
                sync(wantedPlaying, false, transitionProgramId);
            }, Math.max(0, delay));
        }

        function apply(data, autoplay, fromEnded, expectedProgramId) {
            liveSource = data && data.source ? data.source : '';
            scheduleTransition(data);

            if (!data.current_media) {
                flush();
                audio.pause();
                audio.removeAttribute('src');
                audio.load();
                transitionManager.reset();
                mediaId = 0;
                programId = 0;
                title.textContent = emptyLabel;
                program.textContent = '';
                updateButton();
                return;
            }

            var nextMediaId = parseInt(String(data.current_media.media_id || '').replace('media:', ''), 10) || 0;
            var nextProgramId = data.now_playing
                ? (parseInt(String(data.now_playing.program_id || '').replace('program:', ''), 10) || 0)
                : 0;

            if (transitionManager.isMixing() && (data.source === 'rotation' || data.source === 'semi-live') && nextMediaId !== mediaId) {
                return;
            }

            if (expectedProgramId > 0 && nextProgramId !== expectedProgramId && transitionRetryCount < 20) {
                transitionRetryCount++;
                window.setTimeout(function () {
                    sync(autoplay, false, expectedProgramId);
                }, 250);
                return;
            }

            if (expectedProgramId > 0 && nextProgramId === expectedProgramId) {
                transitionRetryCount = 0;
            }

            var streamUrl = data.current_media.stream_url || '';
            var offset = parseInt(data.current_media.offset || 0, 10) || 0;
            if (expectedProgramId > 0 && nextProgramId === expectedProgramId) {
                offset = 0;
            }

            if (fromEnded && nextMediaId !== endedMediaId && nextProgramId === programId) {
                offset = 0;
            }

            if (fromEnded && nextMediaId === endedMediaId
                && endedAt > 0 && offset >= Math.max(0, endedAt - 2)
                && endedRetryCount < 20) {
                endedRetryCount++;
                window.setTimeout(function () {
                    sync(true, true, 0);
                }, 500);
                return;
            }

            if (fromEnded) {
                endedAt = 0;
                endedMediaId = 0;
                endedRetryCount = 0;
            }

            var changed = mediaId !== nextMediaId || audio.getAttribute('src') !== streamUrl;
            mediaId = nextMediaId;
            programId = nextProgramId;
            transitionManager.prepare(data);
            title.textContent = data.current_media.title || '';
            program.textContent = data.now_playing ? (data.now_playing.title || '') : '';
            wave.setExternal(data.current_media.source_kind && data.current_media.source_kind !== 'local');

            function seekAndPlay() {
                try {
                    audio.currentTime = Math.max(0, offset);
                } catch (error) {}
                if (autoplay && wantedPlaying) {
                    wave.start();
                    audio.play().catch(function () {
                        updateButton();
                    });
                }
            }

            if (changed) {
                flush();
                audio.src = streamUrl;
                audio.load();
                if (audio.readyState >= 1) {
                    seekAndPlay();
                } else {
                    audio.addEventListener('loadedmetadata', function once() {
                        audio.removeEventListener('loadedmetadata', once);
                        seekAndPlay();
                    });
                }
                return;
            }

            if (!audio.paused && Math.abs(audio.currentTime - offset) > 5) {
                try {
                    audio.currentTime = offset;
                } catch (error) {}
            }

            if (autoplay && wantedPlaying && audio.paused) {
                wave.start();
                audio.play().catch(function () {
                    updateButton();
                });
            }
        }

        function sync(autoplay, fromEnded, expectedProgramId) {
            fetch(endpoint, {cache: 'no-store', credentials: 'same-origin'})
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('HTTP ' + response.status);
                    }
                    return response.json();
                })
                .then(function (data) {
                    apply(data, autoplay, !!fromEnded, expectedProgramId || 0);
                })
                .catch(function () {
                    updateButton();
                });
        }

        button.addEventListener('click', function () {
            if (!audio.paused) {
                wantedPlaying = false;
                audio.pause();
                return;
            }
            wantedPlaying = true;
            wave.start();
            sync(true, false, 0);
        });

        audio.addEventListener('play', function () {
            updateButton();
            if (mediaId) {
                postEvent(eventEndpoint, mediaId, programId, 'play', 0);
                listenStart = Date.now();
            }
        });
        audio.addEventListener('pause', function () {
            flush();
            updateButton();
        });
        audio.addEventListener('ended', function () {
            flush();
            if (!wantedPlaying) {
                return;
            }
            if (transitionManager.handleEnded()) {
                return;
            }
            endedAt = audio.currentTime || 0;
            endedMediaId = mediaId;
            endedRetryCount = 0;
            sync(true, true, 0);
        });
        window.addEventListener('pagehide', flush);
        window.setInterval(function () {
            if (wantedPlaying) {
                transitionManager.maybeStart();
            }
        }, 100);

        window.setInterval(function () {
            syncTick++;
            if (liveSource === 'semi-live' || syncTick % 5 === 0) {
                sync(wantedPlaying && !audio.paused, false, 0);
            }
        }, 3000);

        wave.draw();
        wantedPlaying = autoplayRequested;
        sync(autoplayRequested, false, 0);
        updateButton();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
}());
